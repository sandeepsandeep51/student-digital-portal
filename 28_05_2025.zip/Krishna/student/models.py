from django.db import models
from django.contrib.auth import get_user_model
from django.utils import timezone

User = get_user_model()

class StudentProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='student_profile')
    student_name = models.CharField(max_length=100)
    roll_number = models.CharField(max_length=20, unique=True)
    semester = models.IntegerField(default=1)
    department = models.CharField(max_length=100, default='Computer Science')  # Added default value
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.student_name

class StudentActivityLog(models.Model):
    STATUS_CHOICES = (
        ('Pending', 'Pending'),
        ('Approved', 'Approved'),
        ('Rejected', 'Rejected'),
    )

    student = models.ForeignKey(User, on_delete=models.CASCADE)
    thought = models.TextField()
    main_mistake = models.TextField(null=True, blank=True)
    critical_observation = models.TextField(null=True, blank=True)
    main_achievement = models.TextField(null=True, blank=True)
    plan_tomorrow = models.TextField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Pending')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

class LeaveRequest(models.Model):
    LEAVE_TYPES = (
        ('Sick', 'Sick Leave'),
        ('Personal', 'Personal Leave'),
    )
    
    STATUS_CHOICES = (
        ('Pending', 'Pending'),
        ('Verified', 'Verified'),
        ('Approved', 'Approved'),
        ('Rejected', 'Rejected'),
    )

    student = models.ForeignKey(User, on_delete=models.CASCADE)
    semester = models.IntegerField(default=1)
    present_hours = models.IntegerField(default=0)
    cumulative_hours = models.IntegerField(default=0)
    leave_type = models.CharField(max_length=20, choices=LEAVE_TYPES, default='Sick')  # Added default
    from_date = models.DateField(default=timezone.now)  # Added default
    to_date = models.DateField(default=timezone.now)    # Added default
    from_time = models.TimeField(default=timezone.now)
    to_time = models.TimeField(default=timezone.now)
    reason = models.TextField(default='')  # Added default
    supporting_document = models.FileField(
        upload_to='leave_documents/', 
        null=True, 
        blank=True,
        verbose_name='Supporting Document'
    )
    
    @property
    def document_status(self):
        if self.supporting_document:
            return self.supporting_document.name.split('/')[-1]  # Returns filename
        return "No document uploaded"
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Pending')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    verified_at = models.DateTimeField(null=True, blank=True)
    verified_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='verified_leaves')
    approved_at = models.DateTimeField(null=True, blank=True)
    approved_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='approved_leaves')
    rejected_at = models.DateTimeField(null=True, blank=True)
    rejected_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='rejected_leaves')

    class Meta:
        ordering = ['-created_at']
    total_days = models.IntegerField(default=1)

    warning_message = models.CharField(max_length=255, blank=True, null=True)








    class Meta:
        ordering = ['-created_at']


class ActivityHours(models.Model):
    STATUS_CHOICES = (
        ('Pending', 'Pending'),
        ('Approved', 'Approved'),
        ('Rejected', 'Rejected'),
    )
    
    student = models.ForeignKey(User, on_delete=models.CASCADE)
    month = models.DateField()
    from_date = models.DateField()
    to_date = models.DateField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Pending')
    feedback = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.student.username} - {self.month.strftime('%B %Y')}"

class ActivityDetail(models.Model):
    activity = models.ForeignKey(ActivityHours, on_delete=models.CASCADE, related_name='details')
    ref_no = models.IntegerField()
    description = models.CharField(max_length=255)
    before_hours = models.DecimalField(max_digits=4, decimal_places=2, default=0)  # Add this line
    monday = models.DecimalField(max_digits=4, decimal_places=2, default=0)
    tuesday = models.DecimalField(max_digits=4, decimal_places=2, default=0)
    wednesday = models.DecimalField(max_digits=4, decimal_places=2, default=0)
    thursday = models.DecimalField(max_digits=4, decimal_places=2, default=0)
    friday = models.DecimalField(max_digits=4, decimal_places=2, default=0)
    saturday = models.DecimalField(max_digits=4, decimal_places=2, default=0)
    weekly_total = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    job_total = models.DecimalField(max_digits=5, decimal_places=2, default=0)

    def __str__(self):
        return f"Activity {self.ref_no} - {self.description[:30]}"

    def save(self, *args, **kwargs):
        # Calculate weekly total
        self.weekly_total = (
            self.monday +
            self.tuesday +
            self.wednesday +
            self.thursday +
            self.friday +
            self.saturday
        )
        
        # Calculate job total (before hours + weekly total)
        self.job_total = self.before_hours + self.weekly_total
        
        super().save(*args, **kwargs)
