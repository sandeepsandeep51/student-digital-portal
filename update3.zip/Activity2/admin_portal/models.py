from django.db import models
from django.conf import settings

class StaffProfile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    staff_name = models.CharField(max_length=100)
    semester = models.IntegerField(choices=[
        (1, 'First Semester'),
        (2, 'Second Semester'),
        (3, 'Third Semester'),
        (4, 'Fourth Semester'),
        (5, 'Fifth Semester'),
        (6, 'Sixth Semester'),
    ], default=1)  # Default to first semester
    section = models.CharField(max_length=1, choices=[
        ('A', 'Section A'),
        ('B', 'Section B'),
        ('C', 'Section C'),
        ('D', 'Section D'),
    ], default='A')  # Default to Section A
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.staff_name


class StudentProfile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    student_name = models.CharField(max_length=100)
    roll_number = models.CharField(max_length=20)
    semester = models.IntegerField(choices=[
        (1, 'First Semester'),
        (2, 'Second Semester'),
        (3, 'Third Semester'),
        (4, 'Fourth Semester'),
        (5, 'Fifth Semester'),
        (6, 'Sixth Semester'),
    ])
    section = models.CharField(max_length=1, choices=[
        ('A', 'Section A'),
        ('B', 'Section B'),
        ('C', 'Section C'),
        ('D', 'Section D'),
    ])
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, 
                                 null=True, related_name='created_students')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.student_name
