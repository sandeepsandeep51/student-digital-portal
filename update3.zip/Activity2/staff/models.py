from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()

class StaffProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='staff_profile')
    staff_name = models.CharField(max_length=100)
    semester = models.CharField(max_length=2)
    section = models.CharField(max_length=1)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.staff_name} - Semester {self.semester} Section {self.section}"

    class Meta:
        ordering = ['semester', 'section']

class ShopTalkSession(models.Model):
    staff = models.ForeignKey(User, on_delete=models.CASCADE)
    topic = models.CharField(max_length=200)
    scheduled_date = models.DateTimeField()
    description = models.TextField(blank=True, null=True)
    assigned_students = models.ManyToManyField(User, related_name='assigned_sessions')

class ShopTalkSubmission(models.Model):
    session = models.ForeignKey(ShopTalkSession, on_delete=models.CASCADE)
    student = models.ForeignKey(User, on_delete=models.CASCADE)
    submitted_file = models.FileField(upload_to='shoptalk_submissions/')
    submission_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=[
        ('submitted', 'Submitted'),
        ('evaluated', 'Evaluated')
    ], default='submitted')
    marks = models.IntegerField(null=True, blank=True)
    feedback = models.TextField(null=True, blank=True)  # Make feedback nullable

    class Meta:
        unique_together = ['session', 'student']
