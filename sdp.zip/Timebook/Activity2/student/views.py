from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required
def student_dashboard(request):
    if request.user.role != 'student':
        return redirect('login')
    context = {
        'pending_leaves': 3,
        'active_projects': 2,
        'shoptalk_sessions': 5,
        'activity_hours': 24
    }
    return render(request, 'student/dashboard.html', context)

@login_required
def student_profile(request):
    return render(request, 'student/profile.html')

@login_required
def student_leave(request):
    return render(request, 'student/leave.html')

@login_required
def student_shoptalk(request):
    return render(request, 'student/shoptalk.html')

@login_required
def student_projects(request):
    return render(request, 'student/projects.html')

@login_required
def student_latecoming(request):
    return render(request, 'student/latecoming.html')

@login_required
def activity_planner(request):
    return render(request, 'student/activity_planner.html')

@login_required
def activity_hours(request):
    return render(request, 'student/activity_hours.html')

@login_required
def feedback(request):
    return render(request, 'student/feedback.html')
