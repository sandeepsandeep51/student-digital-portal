from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required

@login_required
def staff_dashboard(request):
    if request.user.role != 'staff':
        return redirect('login')
    context = {
        'total_students': 45,
        'pending_leaves': 7,
        'todays_activities': 3,
        'late_comers': 2
    }
    return render(request, 'staff/dashboard.html', context)

@login_required
def staff_profile(request):
    if request.user.role != 'staff':
        return redirect('login')
    return render(request, 'staff/profile.html')

@login_required
def student_details(request):
    return render(request, 'staff/student_details.html')

@login_required
def leave_requests(request):
    return render(request, 'staff/leave_requests.html')

@login_required
def staff_shoptalk(request):
    return render(request, 'staff/shoptalk.html')

@login_required
def staff_activity_planner(request):
    return render(request, 'staff/activity_planner.html')

@login_required
def staff_activity_hours(request):
    return render(request, 'staff/activity_hours.html')
