from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required

@login_required
def admin_profile(request):
    if request.user.role != 'admin':
        return redirect('login')
    return render(request, 'admin_portal/profile.html')

@login_required
def admin_dashboard(request):
    if request.user.role != 'admin':
        return redirect('login')
    context = {
        'total_students': 150,
        'total_staff': 12,
        'active_projects': 8,
        'pending_leaves': 15
    }
    return render(request, 'admin_portal/dashboard.html', context)

@login_required
def staff_management(request):
    return render(request, 'admin_portal/staff_management.html')

@login_required
def student_management(request):
    return render(request, 'admin_portal/student_management.html')

@login_required
def leave_management(request):
    return render(request, 'admin_portal/leave_management.html')

@login_required
def activity_management(request):
    return render(request, 'admin_portal/activity_management.html')

@login_required
def reports(request):
    return render(request, 'admin_portal/reports.html')
