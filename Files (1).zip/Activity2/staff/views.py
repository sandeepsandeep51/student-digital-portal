from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth import get_user_model
from admin_portal.models import StudentProfile

User = get_user_model()

@login_required
def staff_dashboard(request):
    if request.user.role != 'staff':
        return redirect('login')
    context = {
        'total_students': 45,
        'pending_leaves': 7,
        'todays_activities': 3,
        'late_comers': 2
    }
    return render(request, 'staff/dashboard.html', context)

@login_required
def staff_profile(request):
    if request.user.role != 'staff':
        return redirect('login')
    return render(request, 'staff/profile.html')

@login_required
def student_details(request):
    if request.user.role != 'staff':
        return redirect('login')
    
    students = StudentProfile.objects.filter(created_by=request.user)
    return render(request, 'staff/student_details.html', {'students': students})

@login_required
def create_student(request):
    if request.user.role != 'staff':
        return redirect('login')
        
    if request.method == 'POST':
        password = request.POST['password']
        confirm_password = request.POST['confirm_password']
        
        if password != confirm_password:
            messages.error(request, 'Passwords do not match!')
            return redirect('student_details')
            
        try:
            user = User.objects.create_user(
                username=request.POST['username'],
                password=password,
                email=request.POST['email'],
                role='student'  # This will allow student login
            )
            
            student = StudentProfile.objects.create(
                user=user,
                student_name=request.POST['student_name'],
                roll_number=request.POST['roll_number'],
                semester=request.POST['semester'],
                section=request.POST['section'],
                created_by=request.user
            )
            
            messages.success(request, f'Student account created successfully for {student.student_name}')
        except Exception as e:
            messages.error(request, f'Error creating student account: {str(e)}')
            
    return redirect('student_details')

@login_required
def edit_student(request, student_id):
    if request.user.role != 'staff':
        return redirect('login')
        
    student = StudentProfile.objects.get(id=student_id, created_by=request.user)
    
    if request.method == 'POST':
        student.student_name = request.POST['student_name']
        student.roll_number = request.POST['roll_number']
        student.user.email = request.POST['email']
        student.semester = request.POST['semester']
        student.section = request.POST['section']
        
        if request.POST.get('password'):
            student.user.set_password(request.POST['password'])
            
        student.user.save()
        student.save()
        messages.success(request, 'Student details updated successfully')
        return redirect('student_details')
        
    return render(request, 'staff/edit_student.html', {'student': student})

@login_required
def delete_student(request, student_id):
    if request.user.role != 'staff':
        return redirect('login')
        
    try:
        student = StudentProfile.objects.get(id=student_id, created_by=request.user)
        user = student.user
        student.delete()
        user.delete()
        messages.success(request, 'Student deleted successfully')
    except Exception as e:
        messages.error(request, f'Error deleting student: {str(e)}')
        
    return redirect('student_details')

@login_required
def leave_requests(request):
    return render(request, 'staff/leave_requests.html')

@login_required
def staff_shoptalk(request):
    return render(request, 'staff/shoptalk.html')

@login_required
def staff_activity_planner(request):
    return render(request, 'staff/activity_planner.html')

@login_required
def staff_activity_hours(request):
    return render(request, 'staff/activity_hours.html')
