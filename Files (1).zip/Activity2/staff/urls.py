from django.urls import path
from . import views

urlpatterns = [
    path('', views.staff_dashboard, name='staff_dashboard'),
    path('profile/', views.staff_profile, name='staff_profile'),
    path('student-details/', views.student_details, name='student_details'),
    path('student-details/create/', views.create_student, name='create_student'),
    path('student-details/edit/<int:student_id>/', views.edit_student, name='edit_student'),
    path('student-details/delete/<int:student_id>/', views.delete_student, name='delete_student'),
    path('leave-requests/', views.leave_requests, name='leave_requests'),
    path('shoptalk/', views.staff_shoptalk, name='staff_shoptalk'),
    path('activity-planner/', views.staff_activity_planner, name='staff_activity_planner'),
    path('activity-hours/', views.staff_activity_hours, name='staff_activity_hours'),
]