from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.http import require_POST
import json

@login_required
def student_dashboard(request):
    if request.user.role != 'student':
        return redirect('login')
    return render(request, 'student/dashboard.html')

@login_required
def student_profile(request):
    if request.user.role != 'student':
        return redirect('login')
    return render(request, 'student/profile.html')

@login_required
def student_leave(request):
    if request.user.role != 'student':
        return redirect('login')
    return render(request, 'student/leave.html')

@login_required
def student_shoptalk(request):
    if request.user.role != 'student':
        return redirect('login')
    return render(request, 'student/shoptalk.html')

@login_required
def student_projects(request):
    if request.user.role != 'student':
        return redirect('login')
    return render(request, 'student/projects.html')

@login_required
def student_latecoming(request):
    return render(request, 'student/latecoming.html')

@login_required
def activity_planner(request):
    return render(request, 'student/activity_planner.html')

@login_required
def activity_hours(request):
    return render(request, 'student/activity_hours.html')

@login_required
def feedback(request):
    return render(request, 'student/feedback.html')


@require_POST
def update_profile(request):
    data = json.loads(request.body)
    field = data.get('field')
    value = data.get('value')
    
    if field in ['phone', 'address']:
        student_profile = request.user.studentprofile
        setattr(student_profile, field, value)
        student_profile.save()
        return JsonResponse({'success': True})
    
    return JsonResponse({'success': False})


@login_required
def edit_profile(request):
    if request.method == 'POST':
        student = request.user.studentprofile
        student.update_profile(
            student_name=request.POST.get('student_name'),
            phone=request.POST.get('phone'),
            email=request.POST.get('email'),
            present_address=request.POST.get('present_address'),
            permanent_address=request.POST.get('permanent_address'),
            parent_name=request.POST.get('parent_name'),
            parent_contact=request.POST.get('parent_contact'),
            date_of_birth=request.POST.get('date_of_birth'),
        )
        messages.success(request, 'Profile updated successfully')
        return redirect('student_profile')
    return render(request, 'student/edit_profile.html', {'student': request.user.studentprofile})
