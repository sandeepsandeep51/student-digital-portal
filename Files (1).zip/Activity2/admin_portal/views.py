from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth import get_user_model
from .models import StaffProfile, StudentProfile  # Add StudentProfile here
from django.db.models import Sum, Avg
from .models import ActivityPlanner, ActivityHours

User = get_user_model()  # Get the correct User model

@login_required
def admin_profile(request):
    if request.user.role != 'admin':
        return redirect('login')
    
    context = {
        'admin': request.user,
        'total_staff': StaffProfile.objects.count(),
        'total_students': StudentProfile.objects.count(),
        'recent_activities': ActivityPlanner.objects.order_by('-created_at')[:5]
    }
    return render(request, 'admin_portal/admin_profile.html', context)

@login_required
def activity_planner_performance(request):
    if request.user.role != 'admin':
        return redirect('login')
    
    # Get performance metrics
    students = StudentProfile.objects.all()
    performance_data = {
        'total_activities': ActivityPlanner.objects.count(),
        'completed_activities': ActivityPlanner.objects.filter(status='completed').count(),
        'pending_activities': ActivityPlanner.objects.filter(status='pending').count(),
        'student_performances': []
    }
    
    for student in students:
        student_activities = ActivityPlanner.objects.filter(student=student)
        completion_rate = (student_activities.filter(status='completed').count() / 
                         student_activities.count() * 100) if student_activities.count() > 0 else 0
        
        performance_data['student_performances'].append({
            'student_name': student.student_name,
            'total_activities': student_activities.count(),
            'completed_activities': student_activities.filter(status='completed').count(),
            'completion_rate': round(completion_rate, 2)
        })
    
    return render(request, 'admin_portal/activity_planner_performance.html', 
                 {'performance_data': performance_data})

@login_required
def activity_hours_performance(request):
    if request.user.role != 'admin':
        return redirect('login')
    
    # Get activity hours metrics
    students = StudentProfile.objects.all()
    hours_data = {
        'total_hours_logged': ActivityHours.objects.aggregate(Sum('hours'))['hours__sum'] or 0,
        'average_hours_per_student': ActivityHours.objects.aggregate(Avg('hours'))['hours__avg'] or 0,
        'student_hours': []
    }
    
    for student in students:
        student_hours = ActivityHours.objects.filter(student=student)
        total_hours = student_hours.aggregate(Sum('hours'))['hours__sum'] or 0
        target_hours = 120  # Example target hours per semester
        
        hours_data['student_hours'].append({
            'student_name': student.student_name,
            'total_hours': total_hours,
            'target_completion': round((total_hours / target_hours) * 100, 2),
            'activities_count': student_hours.count()
        })
    
    return render(request, 'admin_portal/activity_hours_performance.html', 
                 {'hours_data': hours_data})

@login_required
def admin_dashboard(request):
    if request.user.role != 'admin':
        return redirect('login')
    context = {
        'total_students': 150,
        'total_staff': 12,
        'active_projects': 8,
        'pending_leaves': 15
    }
    return render(request, 'admin_portal/dashboard.html', context)

@login_required
def staff_management(request):
    if request.user.role != 'admin':
        return redirect('login')
        
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        email = request.POST['email']
        staff_name = request.POST['staff_name']
        semester = request.POST['semester']
        section = request.POST['section']

        try:
            # Create user account with staff role
            user = User.objects.create_user(
                username=username,
                password=password,
                email=email,
                role='staff'
            )
            
            # Create staff profile with semester and section
            staff = StaffProfile.objects.create(
                user=user,
                staff_name=staff_name,
                semester=semester,
                section=section
            )
            
            messages.success(request, f'Staff account created successfully for {staff_name}')
        except Exception as e:
            messages.error(request, f'Error creating staff account: {str(e)}')
        
        return redirect('staff_management')

    # Filter staffs based on semester and section if provided
    semester_filter = request.GET.get('semester')
    section_filter = request.GET.get('section')
    
    staffs = StaffProfile.objects.all()
    if semester_filter:
        staffs = staffs.filter(semester=semester_filter)
    if section_filter:
        staffs = staffs.filter(section=section_filter)
        
    return render(request, 'admin_portal/staff_management.html', {'staffs': staffs})

@login_required
def student_management(request):
    return render(request, 'admin_portal/student_management.html')

@login_required
def leave_management(request):
    return render(request, 'admin_portal/leave_management.html')

@login_required
def activity_management(request):
    return render(request, 'admin_portal/activity_management.html')

@login_required
def reports(request):
    return render(request, 'admin_portal/reports.html')


@login_required
def delete_staff(request, staff_id):
    if request.user.role != 'admin':
        return redirect('login')
    
    try:
        staff = StaffProfile.objects.get(id=staff_id)
        user = staff.user
        staff.delete()
        user.delete()
        messages.success(request, 'Staff member deleted successfully')
    except Exception as e:
        messages.error(request, f'Error deleting staff member: {str(e)}')
    
    return redirect('staff_management')

@login_required
def edit_staff(request, staff_id):
    if request.user.role != 'admin':
        return redirect('login')
    
    staff = StaffProfile.objects.get(id=staff_id)
    
    if request.method == 'POST':
        staff.staff_name = request.POST['staff_name']
        staff.user.email = request.POST['email']
        staff.semester = request.POST['semester']
        staff.section = request.POST['section']
        
        if request.POST.get('password'):
            staff.user.set_password(request.POST['password'])
        
        staff.user.save()
        staff.save()
        messages.success(request, 'Staff details updated successfully')
        return redirect('staff_management')
        
    return render(request, 'admin_portal/edit_staff.html', {'staff': staff})


@login_required
def view_staff_students(request, staff_id):
    if request.user.role != 'admin':
        return redirect('login')
    
    staff = StaffProfile.objects.get(id=staff_id)
    students = StudentProfile.objects.filter(created_by=staff.user)
    
    return render(request, 'admin_portal/staff_students.html', {
        'staff': staff,
        'students': students
    })
