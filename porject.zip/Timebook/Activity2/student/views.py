from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from staff.models import ShopTalkSession, ShopTalkSubmission
from django.utils import timezone

@login_required
def student_dashboard(request):
    if request.user.role != 'student':
        return redirect('login')
    return render(request, 'student/dashboard.html')

@login_required
def student_profile(request):
    if request.user.role != 'student':
        return redirect('login')
    return render(request, 'student/profile.html')

@login_required
def student_leave(request):
    if request.user.role != 'student':
        return redirect('login')
    return render(request, 'student/leave.html')

@login_required
def student_shoptalk(request):
    if request.method == 'POST' and request.FILES.get('submission_file'):
        session_id = request.POST.get('session_id')
        file = request.FILES['submission_file']
        
        try:
            session = ShopTalkSession.objects.get(id=session_id, assigned_students=request.user)
            submission = ShopTalkSubmission.objects.create(
                session=session,
                student=request.user,
                submitted_file=file,
                status='submitted'  # This will show as 'Pending' in the UI
            )
            messages.success(request, 'File uploaded successfully!')
            return redirect('student_shoptalk')
        except Exception as e:
            messages.error(request, f'Error uploading file: {str(e)}')
    
    sessions = ShopTalkSession.objects.filter(
        assigned_students=request.user
    ).prefetch_related('shoptalksubmission_set')
    
    return render(request, 'student/shoptalk.html', {'sessions': sessions})

@login_required
def student_projects(request):
    if request.user.role != 'student':
        return redirect('login')
    return render(request, 'student/projects.html')

@login_required
def student_latecoming(request):
    return render(request, 'student/latecoming.html')

@login_required
def activity_planner(request):
    return render(request, 'student/activity_planner.html')

@login_required
def activity_hours(request):
    return render(request, 'student/activity_hours.html')

@login_required
def feedback(request):
    return render(request, 'student/feedback.html')
