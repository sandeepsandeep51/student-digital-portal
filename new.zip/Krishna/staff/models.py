from django.db import models
from django.contrib.auth import get_user_model
from django.utils import timezone
from django.conf import settings  # Add this import

User = get_user_model()

class StaffProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='staff_profile')
    staff_name = models.CharField(max_length=100)
    semester = models.CharField(max_length=2)
    section = models.CharField(max_length=1)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.staff_name} - Semester {self.semester} Section {self.section}"

    class Meta:
        ordering = ['semester', 'section']

class ShopTalkSession(models.Model):
    staff = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_sessions')
    topic = models.CharField(max_length=200)
    scheduled_date = models.DateTimeField()
    description = models.TextField(default='No description provided')  # Added default value
    assigned_students = models.ManyToManyField(User, related_name='assigned_sessions')
    created_at = models.DateTimeField(default=timezone.now)
    
    class Meta:
        ordering = ['-scheduled_date']

class ShopTalkSubmission(models.Model):
    STATUS_CHOICES = (
        ('submitted', 'Submitted'),
        ('evaluated', 'Evaluated')
    )
    
    session = models.ForeignKey(ShopTalkSession, on_delete=models.CASCADE)
    student = models.ForeignKey(User, on_delete=models.CASCADE)
    submitted_file = models.FileField(upload_to='shoptalk_submissions/')
    submission_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='submitted')
    marks = models.IntegerField(null=True, blank=True)
    feedback = models.TextField(null=True, blank=True)

    class Meta:
        ordering = ['-submission_date']
        unique_together = ['session', 'student']

class StaffStudent(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='staff_created_students')  # Changed related_name
    staff_student_profile = models.OneToOneField('StaffStudentProfile', on_delete=models.CASCADE)

class StaffStudentProfile(models.Model):
    student_name = models.CharField(max_length=100)
    roll_number = models.CharField(max_length=20)


# Update the WeekendProject model to use User instead of StaffStudent for assigned_students
from django.contrib.auth import get_user_model
from django.db import models

User = get_user_model()

class WeekendProject(models.Model):
    STATUS_CHOICES = (
        ('Scheduled', 'Scheduled'),
        ('Not Submitted', 'Not Submitted'),
        ('Submitted', 'Submitted'),
        ('Pending', 'Pending'),
        ('Completed', 'Completed'),
    )
    
    title = models.CharField(max_length=200)
    description = models.TextField()
    requirements = models.TextField(blank=True, null=True)
    start_date = models.DateField()
    due_date = models.DateField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Scheduled')
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_projects')
    assigned_students = models.ManyToManyField(User, related_name='assigned_projects')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.title


class ProjectSubmission(models.Model):
    STATUS_CHOICES = (
        ('Scheduled', 'Scheduled'),
        ('Not Submitted', 'Not Submitted'),
        ('Submitted', 'Submitted'),
        ('Pending', 'Pending'),
        ('Completed', 'Completed')
    )
    
    project = models.ForeignKey(WeekendProject, on_delete=models.CASCADE)
    student = models.ForeignKey(User, on_delete=models.CASCADE)
    submission_file = models.FileField(upload_to='project_submissions/', null=True, blank=True)
    submission_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Scheduled')
    marks = models.IntegerField(null=True, blank=True)
    feedback = models.TextField(null=True, blank=True)

    class Meta:
        unique_together = ['project', 'student']


# Add this to your existing models.py
class ActivityLog(models.Model):
    staff = models.ForeignKey(User, on_delete=models.CASCADE, related_name='staff_activity_logs')
    thought = models.CharField(max_length=255)
    main_mistake = models.TextField(blank=True, null=True)
    critical_observation = models.TextField(blank=True, null=True)
    main_achievement = models.TextField(blank=True, null=True)
    plan_tomorrow = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=20, default='Pending', 
                            choices=[('Approved', 'Approved'), ('Rejected', 'Rejected'), ('Pending', 'Pending')])
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
