from django.contrib.auth.backends import ModelBackend
from .permissions import has_permission

class RoleBasedPermissionBackend(ModelBackend):
    def has_perm(self, user_obj, perm):
        return has_permission(user_obj, perm)