from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from datetime import datetime, timedelta
from django.utils import timezone  # Add this import
from .models import StudentActivityLog, LeaveRequest  # Update this import
from staff.models import WeekendProject, ProjectSubmission  # Ensure this import is present
from admin_portal.models import StudentProfile
from staff.models import ShopTalkSession, ShopTalkSubmission  # Add this import
from admin_portal.models import LateRecord, ActionLog
from django.http import JsonResponse
from django.middleware.csrf import get_token
from django.shortcuts import get_object_or_404  # Added get_object_or_404
from .models import ActivityHours, ActivityDetail  # Add this import

@login_required
def student_dashboard(request):
    if request.user.role != 'student':
        return redirect('login')
    return render(request, 'student/dashboard.html')

@login_required
def student_profile(request):
    if request.user.role != 'student':
        return redirect('login')
    
    context = {
        'user': request.user,
        'student_profile': StudentProfile.objects.get(user=request.user),
        'created_by': request.user.created_by
    }
    return render(request, 'student/profile.html', context)

@login_required
def update_student_profile(request):
    if request.method == 'POST' and request.user.role == 'student':
        try:
            user = request.user
            student_profile = StudentProfile.objects.get(user=user)
            
            # Update allowed fields
            student_profile.student_name = request.POST.get('student_name')
            user.email = request.POST.get('email')
            user.phone = request.POST.get('phone')
            user.address = request.POST.get('address')
            
            user.save()
            student_profile.save()
            messages.success(request, 'Profile updated successfully')
        except Exception as e:
            messages.error(request, f'Error updating profile: {str(e)}')
    
    return redirect('student_profile')

@login_required
def student_leave(request):
    if request.user.role != 'student':
        return redirect('login')

    student_profile = StudentProfile.objects.get(user=request.user)
    
    if request.method == 'POST':
        try:
            # Get form data
            from_date = request.POST.get('from_date')
            to_date = request.POST.get('to_date')
            from_time = request.POST.get('from_time', '09:00')
            to_time = request.POST.get('to_time', '17:00')
            reason = request.POST.get('reason')
            leave_type = request.POST.get('leave_type')
            supporting_document = request.FILES.get('supporting_document')
            
            # Get hours information and convert to integers
            present_hours = int(request.POST.get('present_hours', 0))
            cumulative_hours = int(request.POST.get('cumulative_hours', 0))
            
            # Validate required fields
            if not all([from_date, to_date, from_time, to_time, reason, leave_type]):
                messages.error(request, 'All fields are required')
                return redirect('student_leave')
            
            # Calculate total days and validate dates
            from_date_obj = datetime.strptime(from_date, '%Y-%m-%d').date()
            to_date_obj = datetime.strptime(to_date, '%Y-%m-%d').date()
            current_date = datetime.now().date()
            
            # Allow leaves within past 10 days
            min_allowed_date = current_date - timedelta(days=10)
            
            # Validate dates
            if from_date_obj > to_date_obj:
                messages.error(request, 'From date cannot be later than to date')
                return redirect('student_leave')
                
            if from_date_obj < min_allowed_date:
                messages.error(request, 'You can only apply for leaves within the past 10 days')
                return redirect('student_leave')
            
            total_days = (to_date_obj - from_date_obj).days + 1

            # Check for existing leave requests
            existing_leave = LeaveRequest.objects.filter(
                student=request.user,
                from_date__lte=to_date_obj,
                to_date__gte=from_date_obj,
                status__in=['Pending', 'Approved']
            ).exists()
            
            if existing_leave:
                messages.error(request, 'You already have a leave request for these dates')
                return redirect('student_leave')

            # Create leave request
            leave = LeaveRequest.objects.create(
                student=request.user,
                from_date=from_date,
                to_date=to_date,
                from_time=from_time,
                to_time=to_time,
                reason=reason,
                leave_type=leave_type,
                total_days=total_days,
                supporting_document=supporting_document,
                present_hours=present_hours,
                cumulative_hours=cumulative_hours,
                status='Pending'
            )

            messages.success(request, 'Leave request submitted successfully!')
            return redirect('student_leave')
        except Exception as e:
            messages.error(request, f'Error submitting leave request: {str(e)}')

    # Get all leave requests ordered by latest first
    leaves = LeaveRequest.objects.filter(student=request.user).order_by('-from_date')
    
    # Get warning letters (leaves with warning status or warning message)
    warning_letters = leaves.filter(status='Warning') | leaves.filter(warning_message__isnull=False)
    
    context = {
        'leaves': leaves,
        'student': student_profile,
        'warning_letters': warning_letters,
        'has_warnings': warning_letters.exists(),
        'warning_count': warning_letters.count()
    }
    return render(request, 'student/leave.html', context)

@login_required
def student_shoptalk(request):
    if request.user.role != 'student':
        return redirect('login')
    
    # Handle file upload
    if request.method == 'POST' and request.FILES.get('submission_file'):
        session_id = request.POST.get('session_id')
        file = request.FILES['submission_file']
        
        try:
            session = ShopTalkSession.objects.get(id=session_id)
            
            # Create submission with pending review status
            submission = ShopTalkSubmission.objects.create(
                session=session,
                student=request.user,
                submitted_file=file,
                status='submitted'  # This will show as "Pending Review"
            )
            messages.success(request, 'File uploaded successfully! Waiting for review.')
            return redirect('student_shoptalk')
        except Exception as e:
            messages.error(request, f'Error uploading file: {str(e)}')
    
    tab = request.GET.get('tab', 'all')
    sessions = ShopTalkSession.objects.filter(assigned_students=request.user)
    
    if tab == 'pending':
        sessions = sessions.filter(shoptalksubmission__status='submitted')
    elif tab == 'submitted':
        sessions = sessions.filter(shoptalksubmission__status='evaluated')
    elif tab == 'not_submitted':
        sessions = sessions.exclude(shoptalksubmission__isnull=False)
    
    sessions = sessions.prefetch_related('shoptalksubmission_set').order_by('-scheduled_date')
    
    context = {
        'sessions': sessions,
        'tab': tab,
        'pending_count': ShopTalkSubmission.objects.filter(
            student=request.user,
            status='submitted'
        ).count(),
        'submitted_count': ShopTalkSubmission.objects.filter(
            student=request.user,
            status='evaluated'
        ).count(),
        'not_submitted_count': ShopTalkSession.objects.filter(
            assigned_students=request.user
        ).exclude(
            shoptalksubmission__student=request.user
        ).count()
    }
    
    return render(request, 'student/shoptalk.html', context)

@login_required
def student_projects(request):
    if request.user.role != 'student':
        return redirect('login')
        
    # Get all projects assigned to the student
    projects = WeekendProject.objects.filter(assigned_students=request.user)
    
    # Get current date for status comparison
    current_date = timezone.now().date()
    
    # Get submission status for each project
    submission_status = {}
    for project in projects:
        try:
            submission = ProjectSubmission.objects.get(
                project=project,
                student=request.user
            )
            submission_status[project.id] = {
                'status': submission.status,
                'marks': submission.marks
            }
        except ProjectSubmission.DoesNotExist:
            submission_status[project.id] = None
    
    context = {
        'projects': projects,
        'submission_status': submission_status,
        'current_date': current_date
    }
    return render(request, 'student/projects.html', context)

@login_required
def student_latecoming(request):
    if request.user.role != 'student':
        return redirect('login')
    
    try:
        student_profile = StudentProfile.objects.get(user=request.user)
        
        if request.method == 'POST':
            # Create late record
            late_record = LateRecord.objects.create(
                student=student_profile,
                date=request.POST.get('date'),
                time_arrived=request.POST.get('time_arrived'),
                reason=request.POST.get('reason')
            )
            
            messages.success(request, 'Late coming record submitted successfully')
            return redirect('student_latecoming')
        
        # Get student's late records
        late_records = LateRecord.objects.filter(
            student=student_profile
        ).order_by('-date', '-time_arrived')
        
        context = {
            'late_records': late_records
        }
        return render(request, 'student/latecoming.html', context)
        
    except StudentProfile.DoesNotExist:
        messages.error(request, 'Student profile not found')
        return redirect('student_dashboard')
    except Exception as e:
        messages.error(request, f'Error: {str(e)}')
        return redirect('student_dashboard')

@login_required
def student_activity_planner(request):
    if request.user.role != 'student':
        return redirect('login')

    if request.method == 'POST':
        if 'resubmit_id' in request.POST:
            # Handle resubmission
            activity = get_object_or_404(StudentActivityLog, id=request.POST.get('resubmit_id'))
            activity.thought = request.POST.get('thought')
            activity.main_mistake = request.POST.get('main_mistake')
            activity.critical_observation = request.POST.get('critical_observation')
            activity.main_achievement = request.POST.get('main_achievement')
            activity.plan_tomorrow = request.POST.get('plan_tomorrow')
            activity.status = 'Pending'  # Reset status to pending
            activity.save()
            messages.success(request, 'Activity log resubmitted successfully!')
        else:
            # Handle new submission
            StudentActivityLog.objects.create(
                student=request.user,
                thought=request.POST.get('thought'),
                main_mistake=request.POST.get('main_mistake'),
                critical_observation=request.POST.get('critical_observation'),
                main_achievement=request.POST.get('main_achievement'),
                plan_tomorrow=request.POST.get('plan_tomorrow')
            )
            messages.success(request, 'Activity log submitted successfully!')
        return redirect('student_activity_planner')

    activity_logs = StudentActivityLog.objects.filter(student=request.user)
    return render(request, 'student/activity_planner.html', {'activity_logs': activity_logs})

@login_required
def activity_hours(request):
    if request.method == 'POST':
        try:
            activity = ActivityHours.objects.create(
                student=request.user,
                month=datetime.strptime(request.POST['month'] + "-01", "%Y-%m-%d"),
                from_date=request.POST['from_date'],
                to_date=request.POST['to_date']
            )

            for i in range(1, 10):
                if request.POST.get(f'description_{i}'):
                    ActivityDetail.objects.create(
                        activity=activity,
                        ref_no=i,
                        description=request.POST.get(f'description_{i}'),
                        before_hours=float(request.POST.get(f'before_hours_{i}', 0)),
                        monday=float(request.POST.get(f'monday_{i}', 0)),
                        tuesday=float(request.POST.get(f'tuesday_{i}', 0)),
                        wednesday=float(request.POST.get(f'wednesday_{i}', 0)),
                        thursday=float(request.POST.get(f'thursday_{i}', 0)),
                        friday=float(request.POST.get(f'friday_{i}', 0)),
                        saturday=float(request.POST.get(f'saturday_{i}', 0)),
                        weekly_total=float(request.POST.get(f'weekly_total_{i}', 0)),
                        job_total=float(request.POST.get(f'job_total_{i}', 0))
                    )
            
            messages.success(request, 'Activity hours saved successfully!')
            return redirect('activity_hours_list')
        except Exception as e:
            messages.error(request, f'Error saving activity hours: {str(e)}')
    
    activities = ActivityHours.objects.filter(student=request.user).order_by('-created_at')
    # Pre-fill the form with today's date
    today = datetime.now().strftime('%Y-%m-%d')
    current_month = datetime.now().strftime('%Y-%m')
    
    return render(request, 'student/activity_hours.html', {
        'today': today,
        'current_month': current_month
    })

@login_required
def activity_hours_list(request):
    if request.user.role != 'student':
        return redirect('login')
        
    activities = ActivityHours.objects.filter(student=request.user).order_by('-created_at')
    return render(request, 'student/activity_hours_list.html', {'activities': activities})

@login_required
def activity_hours_details(request, id):  # Changed from activity_id to id
    try:
        activity = ActivityHours.objects.get(pk=id)
        rows = ActivityDetail.objects.filter(activity=activity)
        
        # Calculate totals
        totals = {
            'before_hours': sum(row.before_hours for row in rows),
            'monday': sum(row.monday for row in rows),
            'tuesday': sum(row.tuesday for row in rows),
            'wednesday': sum(row.wednesday for row in rows),
            'thursday': sum(row.thursday for row in rows),
            'friday': sum(row.friday for row in rows),
            'saturday': sum(row.saturday for row in rows),
            'weekly_total': sum(row.weekly_total for row in rows),
            'job_total': sum(row.job_total for row in rows),
        }

        context = {
            'activity': activity,
            'rows': rows,
            'totals': totals,
        }
        return render(request, 'student/activity_hours_details.html', context)
    except ActivityHours.DoesNotExist:
        messages.error(request, 'Activity not found')
        return redirect('activity_hours_list')

@login_required
def feedback(request):
    return render(request, 'student/feedback.html')


def get_csrf_token(request):
    return JsonResponse({'csrfToken': get_token(request)})


@login_required
def submit_project(request, project_id):
    if request.method == 'POST' and request.user.role == 'student':
        try:
            project = WeekendProject.objects.get(id=project_id)
            submission_file = request.FILES.get('submission_file')
            comments = request.POST.get('comments', '')

            # Create or update submission
            submission, created = ProjectSubmission.objects.get_or_create(
                project=project,
                student=request.user,
                defaults={
                    'submission_file': submission_file,
                    'status': 'submitted',
                    'feedback': comments
                }
            )

            if not created:
                submission.submission_file = submission_file
                submission.status = 'submitted'
                submission.feedback = comments
                submission.save()

            messages.success(request, 'Project submitted successfully!')
        except WeekendProject.DoesNotExist:
            messages.error(request, 'Project not found.')
        except Exception as e:
            messages.error(request, f'Error submitting project: {str(e)}')
    
    return redirect('student_projects')
