from django.urls import path
from . import views

urlpatterns = [
    path('', views.admin_dashboard, name='admin_dashboard'),
    path('profile/', views.admin_profile, name='admin_profile'),
    path('staff-management/', views.staff_management, name='staff_management'),
    path('staff-management/edit/<int:staff_id>/', views.edit_staff, name='edit_staff'),
    path('staff-management/delete/<int:staff_id>/', views.delete_staff, name='delete_staff'),
    path('student-management/', views.student_management, name='student_management'),
    path('leave-management/', views.leave_management, name='leave_management'),
    path('activity-management/', views.activity_management, name='activity_management'),
    path('reports/', views.reports, name='reports'),
    path('staff-management/students/<int:staff_id>/', views.view_staff_students, name='view_staff_students'),
    path('late-records/', views.late_records, name='late_records'),
    path('announcements/', views.announcements, name='announcements'),
    path('download-reports/', views.download_reports, name='download_reports'),
    path('action-logs/', views.action_logs, name='action_logs'),
    path('admin-announcements/', views.admin_announcements, name='admin_announcements'),
    path('update-profile/', views.update_profile, name='update_profile'),
    path('admin-announcements/edit/<int:announcement_id>/', views.edit_announcement, name='edit_announcement'),
    path('admin-announcements/delete/<int:announcement_id>/', views.delete_announcement, name='delete_announcement'),
    path('late-records/add-warning/<int:record_id>/', views.add_warning, name='add_warning'),
]