from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from admin_portal.models import StudentProfile
from staff.models import ShopTalkSession, ShopTalkSubmission  # Add this import

@login_required
def student_dashboard(request):
    if request.user.role != 'student':
        return redirect('login')
    return render(request, 'student/dashboard.html')

@login_required
def student_profile(request):
    if request.user.role != 'student':
        return redirect('login')
    
    context = {
        'user': request.user,
        'student_profile': StudentProfile.objects.get(user=request.user),
        'created_by': request.user.created_by
    }
    return render(request, 'student/profile.html', context)

@login_required
def update_student_profile(request):
    if request.method == 'POST' and request.user.role == 'student':
        try:
            user = request.user
            student_profile = StudentProfile.objects.get(user=user)
            
            # Update allowed fields
            student_profile.student_name = request.POST.get('student_name')
            user.email = request.POST.get('email')
            user.phone = request.POST.get('phone')
            user.address = request.POST.get('address')
            
            user.save()
            student_profile.save()
            messages.success(request, 'Profile updated successfully')
        except Exception as e:
            messages.error(request, f'Error updating profile: {str(e)}')
    
    return redirect('student_profile')

@login_required
def student_leave(request):
    if request.user.role != 'student':
        return redirect('login')
    return render(request, 'student/leave.html')

@login_required
def student_shoptalk(request):
    if request.user.role != 'student':
        return redirect('login')
    
    # Handle file upload
    if request.method == 'POST' and request.FILES.get('submission_file'):
        session_id = request.POST.get('session_id')
        file = request.FILES['submission_file']
        
        try:
            session = ShopTalkSession.objects.get(id=session_id)
            
            # Create submission with pending review status
            submission = ShopTalkSubmission.objects.create(
                session=session,
                student=request.user,
                submitted_file=file,
                status='submitted'  # This will show as "Pending Review"
            )
            messages.success(request, 'File uploaded successfully! Waiting for review.')
            return redirect('student_shoptalk')
        except Exception as e:
            messages.error(request, f'Error uploading file: {str(e)}')
    
    tab = request.GET.get('tab', 'all')
    sessions = ShopTalkSession.objects.filter(assigned_students=request.user)
    
    if tab == 'pending':
        sessions = sessions.filter(shoptalksubmission__status='submitted')
    elif tab == 'submitted':
        sessions = sessions.filter(shoptalksubmission__status='evaluated')
    elif tab == 'not_submitted':
        sessions = sessions.exclude(shoptalksubmission__isnull=False)
    
    sessions = sessions.prefetch_related('shoptalksubmission_set').order_by('-scheduled_date')
    
    context = {
        'sessions': sessions,
        'tab': tab,
        'pending_count': ShopTalkSubmission.objects.filter(
            student=request.user,
            status='submitted'
        ).count(),
        'submitted_count': ShopTalkSubmission.objects.filter(
            student=request.user,
            status='evaluated'
        ).count(),
        'not_submitted_count': ShopTalkSession.objects.filter(
            assigned_students=request.user
        ).exclude(
            shoptalksubmission__student=request.user
        ).count()
    }
    
    return render(request, 'student/shoptalk.html', context)

@login_required
def student_projects(request):
    if request.user.role != 'student':
        return redirect('login')
    return render(request, 'student/projects.html')

@login_required
def student_latecoming(request):
    return render(request, 'student/latecoming.html')

@login_required
def activity_planner(request):
    return render(request, 'student/activity_planner.html')

@login_required
def activity_hours(request):
    return render(request, 'student/activity_hours.html')

@login_required
def feedback(request):
    return render(request, 'student/feedback.html')
