from staff.models import StaffProfile

def staff_list_context(request):
    if request.user.is_authenticated and request.user.role == 'admin':
        staff_list = StaffProfile.objects.filter(
            user__created_by=request.user,
            user__role='staff'
        ).select_related('user')
        return {'staff_list': staff_list}
    return {'staff_list': []}