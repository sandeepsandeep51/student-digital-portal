from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth import get_user_model
from staff.models import StaffProfile
from student.models import StudentProfile
from authentication.models import User  # Add this import

@login_required
def admin_profile(request):
    if request.user.role != 'admin':
        return redirect('login')
    
    context = {
        'username': request.user.username,
        'email': request.user.email,
        'role': request.user.role,
        'center': request.user.center,
        'course': request.user.course,
        'name': f"{request.user.first_name} {request.user.last_name}",
        'phone': request.user.phone,
        'address': request.user.address
    }
    return render(request, 'admin_portal/profile.html', context)

@login_required
def admin_dashboard(request):
    if request.user.role != 'admin':
        return redirect('login')
    context = {
        'total_students': 150,
        'total_staff': 12,
        'active_projects': 8,
        'pending_leaves': 15
    }
    return render(request, 'admin_portal/dashboard.html', context)

@login_required
def staff_management(request):
    if request.user.role != 'admin':
        return redirect('login')

    if request.method == 'POST':
        try:
            # Verify passwords match
            if request.POST['password'] != request.POST['confirm_password']:
                messages.error(request, 'Passwords do not match')
                return redirect('staff_management')

            # Create staff user
            staff_user = User.objects.create_user(
                username=request.POST['username'],
                email=request.POST['email'],
                password=request.POST['password'],
                first_name=request.POST['staff_name'],
                role='staff',
                center=request.user.center,
                course=request.user.course
            )
            
            # Create staff profile
            StaffProfile.objects.create(
                user=staff_user,
                staff_name=request.POST['staff_name'],
                semester=request.POST['semester'],
                section=request.POST['section']
            )
            messages.success(request, 'Staff account created successfully')
        except Exception as e:
            messages.error(request, f'Error creating staff account: {str(e)}')
        
        return redirect('staff_management')

    # Get staff accounts with their profiles
    staffs = StaffProfile.objects.filter(
        user__role='staff',
        user__center=request.user.center,
        user__course=request.user.course
    ).select_related('user')
    
    context = {
        'staffs': staffs
    }
    return render(request, 'admin_portal/staff_management.html', context)

@login_required
def student_management(request):
    if request.user.role != 'admin':
        return redirect('login')
        
    # Get only staff members created by the current admin
    staff_list = StaffProfile.objects.select_related('user').filter(
        user__role='staff',
        user__center=request.user.center,
        user__course=request.user.course,
        user__created_by=request.user  # Only show staff created by current admin
    )
    
    # For each staff, get students created by them
    for staff in staff_list:
        students = StudentProfile.objects.filter(
            user__created_by=staff.user
        ).select_related('user')
        
        staff.students = students
        staff.student_count = students.count()
    
    context = {
        'staff_list': staff_list,
    }
    return render(request, 'admin_portal/student_management.html', context)

@login_required
def leave_management(request):
    return render(request, 'admin_portal/leave_management.html')

@login_required
def activity_management(request):
    return render(request, 'admin_portal/activity_management.html')

@login_required
def reports(request):
    return render(request, 'admin_portal/reports.html')


@login_required
def delete_staff(request, staff_id):
    if request.user.role != 'admin':
        return redirect('login')
    
    try:
        staff = StaffProfile.objects.get(id=staff_id)
        user = staff.user
        staff.delete()
        user.delete()
        messages.success(request, 'Staff member deleted successfully')
    except Exception as e:
        messages.error(request, f'Error deleting staff member: {str(e)}')
    
    return redirect('staff_management')

@login_required
def edit_staff(request, staff_id):
    if request.user.role != 'admin':
        return redirect('login')
    
    staff = StaffProfile.objects.get(id=staff_id)
    
    if request.method == 'POST':
        staff.staff_name = request.POST['staff_name']
        staff.user.email = request.POST['email']
        staff.semester = request.POST['semester']
        staff.section = request.POST['section']
        
        if request.POST.get('password'):
            staff.user.set_password(request.POST['password'])
        
        staff.user.save()
        staff.save()
        messages.success(request, 'Staff details updated successfully')
        return redirect('staff_management')
        
    return render(request, 'admin_portal/edit_staff.html', {'staff': staff})


@login_required
def view_staff_students(request, staff_id):
    if request.user.role != 'admin':
        return redirect('login')
    
    try:
        # Get staff profile
        staff = StaffProfile.objects.get(id=staff_id)
        
        # Debug print to check staff user
        print(f"Staff User ID: {staff.user.id}")
        
        # Get students created by this staff member
        students = StudentProfile.objects.filter(
            created_by=staff.user
        ).select_related('user')
        
        # Debug print to check students
        print(f"Found Students: {students.count()}")
        
        context = {
            'staff': staff,
            'students': students,
            'total_students': students.count()
        }
        
        return render(request, 'admin_portal/staff_students.html', context)
    except StaffProfile.DoesNotExist:
        messages.error(request, 'Staff member not found')
        return redirect('staff_management')
    except Exception as e:
        messages.error(request, f'Error retrieving students: {str(e)}')
        return redirect('staff_management')

@login_required
def late_records(request):
    return render(request, 'admin_portal/late_records.html')

@login_required
def announcements(request):
    return render(request, 'admin_portal/announcements.html')

@login_required
def download_reports(request):
    return render(request, 'admin_portal/download_reports.html')

@login_required
def action_logs(request):
    return render(request, 'admin_portal/action_logs.html')

@login_required
def admin_announcements(request):
    return render(request, 'admin_portal/admin_announcements.html')


@login_required
def update_profile(request):
    if request.method == 'POST':
        user = request.user
        user.first_name = request.POST.get('first_name', '')
        user.last_name = request.POST.get('last_name', '')
        user.phone = request.POST.get('phone', '')
        user.address = request.POST.get('address', '')
        user.save()
        
        messages.success(request, 'Profile updated successfully')
        return redirect('admin_profile')
    return redirect('admin_profile')

@login_required
def update_profile_pic(request):
    if request.method == 'POST' and request.FILES.get('profile_pic'):
        user = request.user
        if user.profile_pic:
            # Delete old profile picture if it exists
            user.profile_pic.delete()
        user.profile_pic = request.FILES['profile_pic']
        user.save()
        messages.success(request, 'Profile picture updated successfully')
    return redirect('admin_profile')
