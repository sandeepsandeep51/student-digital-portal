from django.urls import path
from . import views

app_name = 'superadmin'

urlpatterns = [
    path('dashboard/', views.dashboard, name='dashboard'),
    path('centers/', views.centers, name='centers'),
    path('centers/<int:center_id>/edit/', views.edit_center, name='edit_center'),
    path('centers/<int:center_id>/delete/', views.delete_center, name='delete_center'),
    path('courses/', views.courses, name='courses'),
    path('courses/<int:course_id>/edit/', views.edit_course, name='edit_course'),
    path('courses/<int:course_id>/delete/', views.delete_course, name='delete_course'),
    path('admins/', views.admins, name='admins'),
    path('admins/<int:admin_id>/edit/', views.edit_admin, name='edit_admin'),
    path('admins/<int:admin_id>/delete/', views.delete_admin, name='delete_admin'),  # Keep only one delete path
    path('admins/staff/<int:admin_id>/', views.view_admin_staff, name='view_admin_staff'),
    path('reports/', views.reports, name='reports'),
    path('get-courses/<int:center_id>/', views.get_courses_by_center, name='get_courses_by_center'),
    path('activity-logs/', views.activity_logs, name='activity_logs'),
    path('roles/', views.roles, name='roles'),
    path('roles/add/', views.add_role, name='add_role'),
    path('roles/<int:role_id>/edit/', views.edit_role, name='edit_role'),
    path('roles/<int:role_id>/delete/', views.delete_role, name='delete_role'),
]