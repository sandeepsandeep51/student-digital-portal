from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth import get_user_model
from staff.models import StaffProfile
from student.models import StudentProfile
from authentication.models import User  
from django.shortcuts import render
from django.contrib.auth.decorators import login_required, user_passes_test
from django.core.paginator import Paginator
from .models import ActionLog
from .models import ActionLog, Announcement
from .models import ActionLog, Announcement, LateRecord  # Add LateRecord here
from django.utils import timezone
from datetime import datetime
from student.models import LeaveRequest# Add this import if not already present

def is_admin(user):
    return user.is_authenticated and user.is_staff and user.is_superuser

@login_required
@user_passes_test(is_admin)
def download_reports(request):
    if request.method == 'POST':
        report_type = request.POST.get('report_type')
        date_from = request.POST.get('date_from')
        date_to = request.POST.get('date_to')

        # Generate report based on type and date range
        try:
            # Here you would implement the actual report generation logic
            report = Report.objects.create(
                name=f"{report_type}_{timezone.now().strftime('%Y%m%d')}",
                type=report_type,
                generated_by=request.user,
                date_from=date_from,
                date_to=date_to
            )
            messages.success(request, 'Report generated successfully!')
        except Exception as e:
            messages.error(request, f'Error generating report: {str(e)}')

    # Get all reports for display
    reports = Report.objects.all()
    return render(request, 'admin_portal/download_reports.html', {'reports': reports})

@login_required
def admin_profile(request):
    if request.user.role != 'admin':
        return redirect('login')
    
    context = {
        'username': request.user.username,
        'email': request.user.email,
        'role': request.user.role,
        'center': request.user.center,
        'course': request.user.course,
        'name': f"{request.user.first_name} {request.user.last_name}",
        'phone': request.user.phone,
        'address': request.user.address
    }
    return render(request, 'admin_portal/profile.html', context)

@login_required
def admin_dashboard(request):
    if request.user.role != 'admin':
        return redirect('login')
    context = {
        'total_students': 150,
        'total_staff': 12,
        'active_projects': 8,
        'pending_leaves': 15
    }
    return render(request, 'admin_portal/dashboard.html', context)

@login_required
def staff_management(request):
    if request.user.role != 'admin':
        return redirect('login')

    if request.method == 'POST':
        try:
            # Verify all required fields are present
            required_fields = ['username', 'email', 'password', 'confirm_password', 'staff_name', 'semester', 'section']
            for field in required_fields:
                if not request.POST.get(field):
                    messages.error(request, f'{field.replace("_", " ").title()} is required')
                    return redirect('staff_management')

            # Verify passwords match
            if request.POST['password'] != request.POST['confirm_password']:
                messages.error(request, 'Passwords do not match')
                return redirect('staff_management')

            # Create staff user with all required fields
            staff_user = User.objects.create_user(
                username=request.POST['username'],
                email=request.POST['email'],
                password=request.POST['password'],
                first_name=request.POST['staff_name'],
                role='staff',
                center=request.user.center,
                course=request.user.course,
                created_by=request.user  # Add this to track who created the staff
            )
            
            # Create staff profile with all required fields
            StaffProfile.objects.create(
                user=staff_user,
                staff_name=request.POST['staff_name'],
                semester=request.POST['semester'],
                section=request.POST['section']
            )

            # Log the action
            ActionLog.objects.create(
                user=request.user,
                action_type='CREATE',
                action_description=f'Created new staff account for {request.POST["staff_name"]}',
                ip_address=request.META.get('REMOTE_ADDR')
            )
            
            messages.success(request, 'Staff account created successfully')
        except Exception as e:
            # More detailed error message
            messages.error(request, f'Error creating staff account: {str(e)}')
            print(f"Staff creation error: {str(e)}")  # Add logging for debugging
        
        return redirect('staff_management')

    # Get staff accounts with their profiles
    staffs = StaffProfile.objects.filter(
        user__role='staff',
        user__center=request.user.center,
        user__course=request.user.course
    ).select_related('user')
    
    context = {
        'staffs': staffs
    }
    return render(request, 'admin_portal/staff_management.html', context)

@login_required
def student_management(request):
    if request.user.role != 'admin':
        return redirect('login')

    students = User.objects.filter(
        role='student',
        course=request.user.course
    )

    student_data = []
    for user in students:
        try:
            profile = user.studentprofile
        except Exception:
            profile = None
        student_data.append({'user': user, 'profile': profile})

    total_students = students.count()

    context = {
        'students': student_data,
        'total_students': total_students,
        'course_name': request.user.course
    }
    return render(request, 'admin_portal/student_management.html', context)

    
        
@login_required
def leave_management(request):
    if request.user.role != 'admin':
        return redirect('login')

    if request.method == 'POST':
        if 'leave_id' in request.POST and 'action' in request.POST:
            leave_id = request.POST.get('leave_id')
            action = request.POST.get('action')
            
            try:
                leave_request = LeaveRequest.objects.get(
                    id=leave_id,
                    student__center=request.user.center,
                    student__course=request.user.course
                )
                
                if action == 'warning':
                    leave_request.status = 'Warning'
                    leave_request.warning_message = f'Warning: Leave request for {leave_request.total_days} days exceeds the 3-day limit. Please provide additional documentation or justification.'
                    action_msg = 'warning issued'
                elif action == 'approve':
                    leave_request.status = 'Approved'
                    action_msg = 'approved'
                elif action == 'reject':
                    leave_request.status = 'Rejected'
                    action_msg = 'rejected'
                
                leave_request.save()
                
                # Log the action
                ActionLog.objects.create(
                    user=request.user,
                    action_type=f'LEAVE_{action.upper()}',
                    action_description=f'Leave request {action_msg} for {leave_request.student.studentprofile.student_name}'
                )
                
                messages.success(request, f'Leave request has been {action_msg} successfully')
            except LeaveRequest.DoesNotExist:
                messages.error(request, 'Leave request not found or access denied')
            except Exception as e:
                messages.error(request, f'Error processing request: {str(e)}')
            
            return redirect('leave_management')

    # Handle clear all leave requests
    if request.method == 'POST' and 'clear_all' in request.POST:
        try:
            # Get leave requests only for current admin's center and course
            leave_requests = LeaveRequest.objects.filter(
                student__center=request.user.center,
                student__course=request.user.course
            )
            
            # Create a backup of leave requests for staff history
            for leave in leave_requests:
                ActionLog.objects.create(
                    user=request.user,
                    action_type='LEAVE_CLEARED',
                    action_description=f'Leave request cleared for {leave.student.studentprofile.student_name}',
                    ip_address=request.META.get('REMOTE_ADDR')
                )
            
            # Delete filtered leave requests
            leave_requests.delete()
            
            messages.success(request, 'All leave requests have been cleared successfully')
            return redirect('leave_management')
        except Exception as e:
            messages.error(request, f'Error clearing leave requests: {str(e)}')
            return redirect('leave_management')

    # Handle approve/reject/warning actions
    if request.method == 'POST':
        leave_id = request.POST.get('leave_id')
        action = request.POST.get('action')
        
        try:
            leave_request = LeaveRequest.objects.get(
                id=leave_id,
                student__center=request.user.center,
                student__course=request.user.course
            )
            
            if leave_request.total_days > 3:
                # For leaves over 3 days, automatically set warning status
                leave_request.status = 'Warning'
                leave_request.warning_message = f'Warning: Leave request for {leave_request.total_days} days exceeds the 3-day limit.'
                action_msg = 'warning issued'
            else:
                # Normal approve/reject flow for leaves up to 3 days
                if action == 'approve':
                    leave_request.status = 'Approved'
                    action_msg = 'approved'
                elif action == 'reject':
                    leave_request.status = 'Rejected'
                    action_msg = 'rejected'
            
            leave_request.save()
            
            # Log the action
            ActionLog.objects.create(
                user=request.user,
                action_type=f'LEAVE_{action.upper()}',
                action_description=f'Leave request {action_msg} for {leave_request.student.studentprofile.student_name}'
            )
            
            messages.success(request, f'Leave request has been {action_msg} successfully')
        except LeaveRequest.DoesNotExist:
            messages.error(request, 'Leave request not found or access denied')
        except Exception as e:
            messages.error(request, f'Error processing request: {str(e)}')
        
        return redirect('leave_management')

    # Get leave requests only for current admin's center and course
    leave_requests = LeaveRequest.objects.select_related(
        'student__studentprofile',
        'student'
    ).filter(
        student__center=request.user.center,
        student__course=request.user.course
    ).order_by('-from_date')

    # Apply filters
    student_name = request.GET.get('student_name')
    date_from = request.GET.get('date_from')
    date_to = request.GET.get('date_to')

    if student_name:
        leave_requests = leave_requests.filter(
            student__studentprofile__student_name__icontains=student_name
        )
    if date_from:
        leave_requests = leave_requests.filter(from_date__gte=date_from)
    if date_to:
        leave_requests = leave_requests.filter(to_date__lte=date_to)

    context = {
        'leave_requests': leave_requests
    }
    return render(request, 'admin_portal/leave_management.html', context)

@login_required
def activity_management(request):
    return render(request, 'admin_portal/activity_management.html')

@login_required
def reports(request):
    return render(request, 'admin_portal/reports.html')


@login_required
def delete_staff(request, staff_id):
    if request.user.role != 'admin':
        return redirect('login')
    
    try:
        staff = StaffProfile.objects.get(id=staff_id)
        staff_name = staff.staff_name
        user = staff.user
        staff.delete()
        user.delete()
        
        # Add action log
        ActionLog.objects.create(
            user=request.user,
            action_type='DELETE',
            action_description=f'Deleted staff member: {staff_name}',
            ip_address=request.META.get('REMOTE_ADDR')
        )
        messages.success(request, 'Staff member deleted successfully')
    except Exception as e:
        messages.error(request, f'Error deleting staff member: {str(e)}')
    
    return redirect('staff_management')

@login_required
def edit_staff(request, staff_id):
    if request.user.role != 'admin':
        return redirect('login')
    
    staff = StaffProfile.objects.get(id=staff_id)
    
    if request.method == 'POST':
        staff.staff_name = request.POST['staff_name']
        staff.user.email = request.POST['email']
        staff.semester = request.POST['semester']
        staff.section = request.POST['section']
        
        if request.POST.get('password'):
            staff.user.set_password(request.POST['password'])
        
        staff.user.save()
        staff.save()
        
        # Add action log
        ActionLog.objects.create(
            user=request.user,
            action_type='UPDATE',
            action_description=f'Updated staff details for {staff.staff_name}',
            ip_address=request.META.get('REMOTE_ADDR')
        )
        messages.success(request, 'Staff details updated successfully')
        return redirect('staff_management')
        
    return render(request, 'admin_portal/edit_staff.html', {'staff': staff})


@login_required
def view_staff_students(request, staff_id):
    if request.user.role != 'admin':
        return redirect('login')
    
    try:
        # Get staff profile
        staff = StaffProfile.objects.get(id=staff_id)
        
        # Debug print to check staff user
        print(f"Staff User ID: {staff.user.id}")
        
        # Get students created by this staff member
        students = StudentProfile.objects.filter(
            created_by=staff.user
        ).select_related('user')
        
        # Debug print to check students
        print(f"Found Students: {students.count()}")
        
        context = {
            'staff': staff,
            'students': students,
            'total_students': students.count()
        }
        
        return render(request, 'admin_portal/staff_students.html', context)
    except StaffProfile.DoesNotExist:
        messages.error(request, 'Staff member not found')
        return redirect('staff_management')
    except Exception as e:
        messages.error(request, f'Error retrieving students: {str(e)}')
        return redirect('staff_management')

@login_required
def late_records(request):
    if request.user.role != 'admin':
        return redirect('login')

    # Get late records for students in admin's course
    late_records = LateRecord.objects.filter(
        student__user__course=request.user.course
    ).select_related('student', 'student__user').order_by('-date', '-time_arrived')

    # Apply filters
    date_from = request.GET.get('date_from')
    date_to = request.GET.get('date_to')
    student_name = request.GET.get('student_name')
    semester = request.GET.get('semester')

    if date_from:
        late_records = late_records.filter(date__gte=date_from)
    if date_to:
        late_records = late_records.filter(date__lte=date_to)
    if student_name:
        late_records = late_records.filter(student__student_name__icontains=student_name)
    if semester:
        late_records = late_records.filter(student__semester__icontains=semester)

    context = {
        'late_records': late_records
    }
    return render(request, 'admin_portal/late_records.html', context)

@login_required
def add_warning(request, record_id):
    if request.user.role != 'admin':
        return redirect('login')

    if request.method == 'POST':
        try:
            record = LateRecord.objects.get(
                id=record_id,
                student__user__course=request.user.course
            )
            warning_message = request.POST.get('warning_message')
            if warning_message:
                record.warning_message = warning_message
                record.save()

                # Log the action
                ActionLog.objects.create(
                    user=request.user,
                    action_type='UPDATE',
                    action_description=f'Added warning message for {record.student.student_name}\'s late record',
                    ip_address=request.META.get('REMOTE_ADDR')
                )

                messages.success(request, 'Warning message added successfully')
            else:
                messages.error(request, 'Warning message cannot be empty')
        except LateRecord.DoesNotExist:
            messages.error(request, 'Late record not found')

    return redirect('late_records')

@login_required
def announcements(request):
    return render(request, 'admin_portal/announcements.html')

@login_required
def download_reports(request):
    if request.user.role != 'admin':
        return redirect('login')
    
    context = {}
    
    if request.GET:
        report_type = request.GET.get('report_type')
        date_from = request.GET.get('date_from')
        date_to = request.GET.get('date_to')
        
        if report_type and date_from and date_to:
            # Get students in admin's course
            students = StudentProfile.objects.filter(
                user__course=request.user.course,
                user__center=request.user.center
            ).select_related('user')
            
            headers = []
            report_data = []
            
            if report_type == 'attendance':
                headers = ['Student Name', 'Total Days', 'Present Days', 'Percentage']
                for student in students:
                    # Replace with actual attendance calculations
                    report_data.append([
                        student.student_name,
                        '30',
                        '25',
                        '83.33%'
                    ])
                    
            elif report_type == 'late_coming':
                headers = ['Student Name', 'Late Days', 'Total Minutes Late', 'Warnings']
                for student in students:
                    late_records = LateRecord.objects.filter(
                        student=student,
                        date__range=[date_from, date_to]
                    )
                    report_data.append([
                        student.student_name,
                        late_records.count(),
                        sum(record.minutes_late for record in late_records),
                        late_records.filter(warning_message__isnull=False).count()
                    ])
                    
            elif report_type == 'performance':
                headers = ['Student Name', 'Assignments', 'Projects', 'Overall Grade']
                for student in students:
                    report_data.append([
                        student.student_name,
                        '85%',
                        '90%',
                        'A'
                    ])
                    
            elif report_type == 'activity':
                headers = ['Student Name', 'Activities Completed', 'Hours Spent', 'Rating']
                for student in students:
                    report_data.append([
                        student.student_name,
                        '8',
                        '24',
                        'Good'
                    ])
            
            context.update({
                'headers': headers,
                'report_data': report_data
            })
            
            # Log the report generation
            ActionLog.objects.create(
                user=request.user,
                action_type='REPORT',
                action_description=f'Generated {report_type} report',
                ip_address=request.META.get('REMOTE_ADDR')
            )
    
    return render(request, 'admin_portal/download_reports.html', context)

@login_required
@user_passes_test(lambda u: u.is_staff)
def action_logs(request):
    # Get filter parameters
    date_from = request.GET.get('date_from')
    date_to = request.GET.get('date_to')
    action_type = request.GET.get('action_type')

    # Base queryset
    logs = ActionLog.objects.all()

    # Apply filters
    if date_from:
        logs = logs.filter(timestamp__date__gte=datetime.strptime(date_from, '%Y-%m-%d').date())
    if date_to:
        logs = logs.filter(timestamp__date__lte=datetime.strptime(date_to, '%Y-%m-%d').date())
    if action_type:
        logs = logs.filter(action_type=action_type)

    # Pagination
    paginator = Paginator(logs, 25)  # Show 25 logs per page
    page = request.GET.get('page')
    logs = paginator.get_page(page)

    context = {
        'logs': logs,
        'action_types': ActionLog.ACTION_TYPES,
    }
    return render(request, 'admin_portal/action_logs.html', context)

@login_required
def admin_announcements(request):
    if request.user.role != 'admin':
        return redirect('login')
    
    if request.method == 'POST':
        title = request.POST.get('title')
        content = request.POST.get('content')
        
        try:
            # Create announcement
            announcement = Announcement.objects.create(
                title=title,
                content=content,
                created_by=request.user
            )
            
            # Get all staff members created by this admin
            staff_members = User.objects.filter(role='staff', created_by=request.user)
            announcement.staff_recipients.add(*staff_members)
            
            messages.success(request, 'Announcement created successfully!')
        except Exception as e:
            messages.error(request, str(e))
    
    # Get all announcements by this admin
    announcements = Announcement.objects.filter(
        created_by=request.user
    ).order_by('-created_at')
    
    context = {
        'announcements': announcements
    }
    return render(request, 'admin_portal/admin_announcements.html', context)


@login_required
def update_profile(request):
    if request.method == 'POST':
        user = request.user
        user.first_name = request.POST.get('first_name', '')
        user.last_name = request.POST.get('last_name', '')
        user.phone = request.POST.get('phone', '')
        user.address = request.POST.get('address', '')
        user.save()
        
        # Add action log
        ActionLog.objects.create(
            user=request.user,
            action_type='UPDATE',
            action_description='Updated profile information',
            ip_address=request.META.get('REMOTE_ADDR')
        )
        messages.success(request, 'Profile updated successfully')
        return redirect('admin_profile')
    return redirect('admin_profile')

@login_required
def update_profile_pic(request):
    if request.method == 'POST' and request.FILES.get('profile_pic'):
        user = request.user
        if user.profile_pic:
            # Delete old profile picture if it exists
            user.profile_pic.delete()
        user.profile_pic = request.FILES['profile_pic']
        user.save()
        messages.success(request, 'Profile picture updated successfully')
    return redirect('admin_profile')


@login_required
def edit_announcement(request, announcement_id):
    if request.user.role != 'admin':
        return redirect('login')
    
    try:
        announcement = Announcement.objects.get(id=announcement_id, created_by=request.user)
        
        if request.method == 'POST':
            announcement.title = request.POST.get('title')
            announcement.content = request.POST.get('content')
            announcement.save()
            
            messages.success(request, 'Announcement updated successfully!')
            return redirect('admin_announcements')
            
        context = {
            'announcement': announcement
        }
        return render(request, 'admin_portal/edit_announcement.html', context)
        
    except Announcement.DoesNotExist:
        messages.error(request, 'Announcement not found.')
        return redirect('admin_announcements')

@login_required
def delete_announcement(request, announcement_id):
    if request.user.role != 'admin':
        return redirect('login')
    
    try:
        announcement = Announcement.objects.get(id=announcement_id, created_by=request.user)
        title = announcement.title
        announcement.delete()
        
        ActionLog.objects.create(
            user=request.user,
            action_type='DELETE',
            action_description=f'Deleted announcement: {title}',
            ip_address=request.META.get('REMOTE_ADDR')
        )
        
        messages.success(request, 'Announcement deleted successfully')
    except Announcement.DoesNotExist:
        messages.error(request, 'Announcement not found')
    
    return redirect('admin_announcements')
