from django.db import models
from authentication.models import User

class Center(models.Model):
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=20, default='DEFAULT')
    location = models.CharField(max_length=200)
    contact_number = models.CharField(max_length=15, default='0000000000')
    email = models.EmailField(max_length=254, default='default@example.com')  # Changed from description to email
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_centers', null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

class Course(models.Model):
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=20)
    description = models.TextField()
    center = models.ForeignKey(Center, on_delete=models.CASCADE)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_courses', null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.code} - {self.name}"

class Role(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    permissions = models.JSONField(default=list)  # Add default value as empty list
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name


class ActivityLog(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    action = models.CharField(max_length=255)
    details = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.action}"
