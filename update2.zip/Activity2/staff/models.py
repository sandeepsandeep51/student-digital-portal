from django.db import models
from authentication.models import User

class ShopTalkSession(models.Model):
    staff = models.ForeignKey(User, on_delete=models.CASCADE)
    topic = models.CharField(max_length=200)
    scheduled_date = models.DateTimeField()
    description = models.TextField(blank=True, null=True)
    assigned_students = models.ManyToManyField(User, related_name='assigned_sessions')

class ShopTalkSubmission(models.Model):
    session = models.ForeignKey(ShopTalkSession, on_delete=models.CASCADE)
    student = models.ForeignKey(User, on_delete=models.CASCADE)
    submitted_file = models.FileField(upload_to='shoptalk_submissions/')
    submission_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=[
        ('submitted', 'Submitted'),
        ('evaluated', 'Evaluated')
    ], default='submitted')
    marks = models.IntegerField(null=True, blank=True)
    feedback = models.TextField(null=True, blank=True)  # Make feedback nullable

    class Meta:
        unique_together = ['session', 'student']
