from django import template

register = template.Library()

@register.filter(name='index')
def index(lst, i):
    try:
        return lst[i]
    except (IndexError, TypeError):
        return None