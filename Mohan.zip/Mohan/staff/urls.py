from django.urls import path
from . import views

urlpatterns = [
    path('', views.staff_dashboard, name='staff_dashboard'),
    path('profile/', views.staff_profile, name='staff_profile'),
    path('student-details/', views.student_details, name='student_details'),
    path('create-student/', views.create_student, name='create_student'),
    path('edit-student/<int:student_id>/', views.edit_student, name='edit_student'),
    path('delete-student/<int:student_id>/', views.delete_student, name='delete_student'),
    path('leave-requests/', views.leave_requests, name='leave_requests'),
    path('shoptalk/', views.staff_shoptalk, name='staff_shoptalk'),
    path('shoptalk/edit/<int:session_id>/', views.edit_session, name='edit_session'),
    path('shoptalk/delete/<int:session_id>/', views.delete_session, name='delete_session'),
    path('activity-planner/', views.staff_activity_planner, name='staff_activity_planner'),
    path('activity-hours/', views.staff_activity_hours, name='staff_activity_hours'),
    path('projects/', views.staff_projects, name='staff_projects'),
    path('projects/submissions/<int:project_id>/', views.view_project_submissions, name='view_project_submissions'),
    path('projects/submissions/<int:project_id>/evaluate/<int:submission_id>/', views.evaluate_submission, name='evaluate_submission'),
    path('projects/edit/<int:project_id>/', views.edit_project, name='edit_project'),
    path('projects/delete/<int:project_id>/', views.delete_project, name='delete_project'),
    path('projects/submission/<int:project_id>/', views.project_submission, name='project_submission'),
    path('performance-analytics/', views.performance_analytics, name='performance_analytics'),
    path('main-announcements/', views.main_announcements, name='main_announcements'),
    path('report-generator/', views.report_generator, name='report_generator'),
    path('activity-log/', views.activity_log, name='activity_log'),
    path('update-profile/', views.update_staff_profile, name='update_staff_profile'),
    path('shoptalk/assign-marks/<int:submission_id>/', views.assign_marks, name='assign_marks'),
]