from django.urls import path
from . import views

urlpatterns = [
    path('', views.student_dashboard, name='student_dashboard'),
    path('profile/', views.student_profile, name='student_profile'),
    path('leave/', views.student_leave, name='student_leave'),
    path('shoptalk/', views.student_shoptalk, name='student_shoptalk'),
    path('projects/', views.student_projects, name='student_projects'),
    path('activity-planner/', views.activity_planner, name='activity_planner'),
    path('activity-hours/', views.activity_hours, name='activity_hours'),
    path('feedback/', views.feedback, name='feedback'),
    path('latecoming/', views.student_latecoming, name='student_latecoming'),
    path('update-profile/', views.update_student_profile, name='update_student_profile'),
    path('get-csrf-token/', views.get_csrf_token, name='get_csrf_token'),
    path('submit-project/<int:project_id>/', views.submit_project, name='submit_project'),
]