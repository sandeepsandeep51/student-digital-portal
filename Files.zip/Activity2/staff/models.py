from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()

class LeaveRequest(models.Model):
    LEAVE_TYPES = (
        ('Sick', 'Sick Leave'),
        ('Personal', 'Personal Leave'),
        ('Emergency', 'Emergency Leave'),
    )
    
    STATUS_CHOICES = (
        ('Pending', 'Pending'),
        ('Approved', 'Approved'),
        ('Rejected', 'Rejected'),
    )

    student = models.ForeignKey(User, on_delete=models.CASCADE)
    leave_type = models.CharField(max_length=20, choices=LEAVE_TYPES)
    start_date = models.DateField()
    end_date = models.DateField()
    reason = models.TextField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Pending')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.student.username} - {self.leave_type} ({self.status})"


class ShopTalk(models.Model):
    topic_name = models.CharField(max_length=200)
    description = models.TextField()
    student_name = models.CharField(max_length=100)
    token_number = models.CharField(max_length=20)
    scheduled_date = models.DateField()
    deadline = models.DateField()
    shoptalk_type = models.CharField(max_length=20)
    status = models.CharField(max_length=20, default='Pending')
    created_at = models.DateTimeField(auto_now_add=True)
    submission_file = models.FileField(upload_to='shoptalk_submissions/', null=True, blank=True)
    submission_date = models.DateTimeField(null=True, blank=True)
    feedback = models.TextField(null=True, blank=True)
    marks = models.IntegerField(null=True, blank=True)
    report = models.TextField(null=True, blank=True)
