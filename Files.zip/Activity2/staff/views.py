from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from django.contrib.auth.hashers import make_password
from student.models import Student, ShopTalkSession, ShopTalkSubmission  # Add ShopTalkSession and ShopTalkSubmission
from django.contrib.auth import get_user_model
from .models import LeaveRequest, ShopTalk  # Add ShopTalk import here

@login_required
def staff_dashboard(request):
    if request.user.role != 'staff':
        return redirect('login')
    return render(request, 'staff/dashboard.html')

@login_required
def staff_profile(request):
    if request.user.role != 'staff':
        return redirect('login')
    return render(request, 'staff/profile.html')

@login_required
def staff_students(request):
    if request.user.role != 'staff':
        return redirect('login')
    
    User = get_user_model()
    students = User.objects.filter(role='student')
    return render(request, 'staff/students.html', {'students': students})

@login_required
def create_student(request):
    if request.method == 'POST':
        try:
            username = request.POST.get('username')
            password = request.POST.get('password')
            name = request.POST.get('name')
            center = request.POST.get('center')
            token_number = request.POST.get('token_number')
            semester = request.POST.get('semester')
            section = request.POST.get('section')

            # Check if token number already exists
            if Student.objects.filter(token_number=token_number).exists():
                messages.error(request, f'Token number {token_number} is already in use. Please use a different token number.')
                return render(request, 'staff/create_student.html')

            student = Student.objects.create_user(
                username=username,
                password=password,
                first_name=name,
                center=center,
                token_number=token_number,
                semester=semester,
                section=section,
                role='student'
            )
            messages.success(request, 'Student created successfully!')
            return redirect('staff_students')
        except Exception as e:
            messages.error(request, f'Error creating student: {str(e)}')
        return redirect('staff_students')
    return render(request, 'staff/create_student.html')

@login_required
def modify_student(request, student_id=None):
    if student_id:
        student = get_object_or_404(Student, id=student_id)
        if request.method == 'POST':
            try:
                student.first_name = request.POST.get('name')
                student.center = request.POST.get('center')
                student.token_number = request.POST.get('token_number')
                student.semester = request.POST.get('semester')
                student.section = request.POST.get('section')
                student.save()
                messages.success(request, 'Student updated successfully!')
            except Exception as e:
                messages.error(request, f'Error updating student: {str(e)}')
            return redirect('staff_students')
        return render(request, 'staff/modify_student.html', {'student': student})
    
    # Search form
    query = request.GET.get('query')
    if query:
        students = Student.objects.filter(
            Q(username__icontains=query) |
            Q(first_name__icontains=query) |
            Q(token_number__icontains=query)
        )
        return render(request, 'staff/modify_student.html', {'students': students})
    return render(request, 'staff/modify_student.html')

@login_required
def delete_student(request, student_id):
    student = get_object_or_404(Student, id=student_id)
    if request.method == 'POST':
        student.delete()
        messages.success(request, 'Student deleted successfully!')
        return redirect('staff_students')
    return render(request, 'staff/delete_student.html', {'student': student})

@login_required
def staff_leave_tracker(request):
    if request.user.role != 'staff':
        return redirect('login')
    
    leave_requests = LeaveRequest.objects.all().order_by('-created_at')
    return render(request, 'staff/leave_tracker.html', {'leave_requests': leave_requests})

@login_required
def staff_shoptalk_central(request):
    return render(request, 'staff/shoptalk_central.html')

@login_required
def staff_shoptalk_schedule(request):
    if request.method == 'POST':
        # Handle form submission
        shoptalk = ShopTalk.objects.create(
            topic_name=request.POST['topic_name'],
            description=request.POST['description'],
            student_name=request.POST['student_name'],
            token_number=request.POST['token_number'],
            scheduled_date=request.POST['scheduled_date'],
            deadline=request.POST['deadline'],
            shoptalk_type=request.POST['shoptalk_type'],
            status='Pending'
        )
        return redirect('staff_shoptalk_list')
    
    type = request.GET.get('type', '1')
    return render(request, 'staff/shoptalk_schedule.html', {'type': type})

@login_required
def staff_shoptalk_submitted(request):
    if request.user.role != 'staff':
        return redirect('login')
        
    # Get all submitted ShopTalk sessions
    submissions = ShopTalk.objects.filter(status='Submitted').order_by('-submission_date')
    return render(request, 'staff/shoptalk_submitted.html', {'submissions': submissions})

@login_required
def staff_shoptalk_pending(request):
    if request.user.role != 'staff':
        return redirect('login')
        
    # Get all pending ShopTalk sessions
    pending = ShopTalk.objects.filter(status='Pending').order_by('deadline')
    
    # Get unique topics for filter dropdown
    topics = ShopTalk.objects.values_list('topic_name', flat=True).distinct()
    
    return render(request, 'staff/shoptalk_pending.html', {
        'pending': pending,
        'topics': topics
    })

@login_required
def staff_shoptalk_list(request):
    if request.user.role != 'staff':
        return redirect('login')
    
    # Change to use ShopTalk model instead of ShopTalkSession
    shoptalk_sessions = ShopTalk.objects.all().order_by('-scheduled_date')
    return render(request, 'staff/shoptalk_list.html', {'sessions': shoptalk_sessions})

@login_required
def staff_shoptalk_details(request, type):
    try:
        session = get_object_or_404(ShopTalk, id=type)
        return render(request, 'staff/shoptalk_details.html', {
            'session': session
        })
    except ShopTalk.DoesNotExist:
        messages.error(request, 'ShopTalk session not found.')
        return redirect('staff_shoptalk_list')

@login_required
def modify_shoptalk(request):
    if request.method == 'POST':
        session_id = request.POST.get('session_id')
        session = get_object_or_404(ShopTalk, id=session_id)
        session.topic_name = request.POST.get('topic_name')
        session.scheduled_date = request.POST.get('scheduled_date')
        session.deadline = request.POST.get('deadline')
        session.save()
        messages.success(request, 'ShopTalk session updated successfully!')
        return redirect('staff_shoptalk_list')
    sessions = ShopTalk.objects.all()
    return render(request, 'staff/modify_shoptalk.html', {'sessions': sessions})

@login_required
def delete_shoptalk(request):
    if request.method == 'POST':
        session_id = request.POST.get('session_id')
        session = get_object_or_404(ShopTalk, id=session_id)
        session.delete()
        messages.success(request, 'ShopTalk session deleted successfully!')
        return redirect('staff_shoptalk_list')
    sessions = ShopTalk.objects.all()
    return render(request, 'staff/delete_shoptalk.html', {'sessions': sessions})

@login_required
def shoptalk_details(request):
    sessions = ShopTalkSession.objects.all().order_by('-scheduled_date')
    return render(request, 'staff/shoptalk_details.html', {
        'sessions': sessions,
        'total_sessions': sessions.count(),
        'pending_sessions': sessions.filter(status='Pending').count(),
        'completed_sessions': sessions.filter(status='Completed').count()
    })


@login_required
def staff_weekend_project(request):
    if request.user.role != 'staff':
        return redirect('login')
    return render(request, 'staff/weekend_project.html')


@login_required
def staff_activity_planner(request):
    if request.user.role != 'staff':
        return redirect('login')
    return render(request, 'staff/activity_planner.html')


@login_required
def staff_activity_hours(request):
    if request.user.role != 'staff':
        return redirect('login')
    
    students = User.objects.filter(role='student')
    return render(request, 'staff/activity_hours.html', {'students': students})

@login_required
def staff_latecoming(request):
    if request.user.role != 'staff':
        return redirect('login')
    
    if request.method == 'POST':
        student_id = request.POST.get('student')
        date = request.POST.get('date')
        time_in = request.POST.get('time_in')
        reason = request.POST.get('reason')
        
        # Here you can add logic to save the late coming record
        messages.success(request, 'Late coming record added successfully!')
        return redirect('staff_latecoming')
    
    students = User.objects.filter(role='student')
    return render(request, 'staff/latecoming.html', {'students': students})


@login_required
def staff_shoptalk_mark(request, shoptalk_id):
    if request.user.role != 'staff':
        return redirect('login')
        
    session = get_object_or_404(ShopTalk, id=shoptalk_id)
    
    if request.method == 'POST':
        marks = request.POST.get('marks')
        report = request.POST.get('report')
        
        if marks and 0 <= int(marks) <= 10:
            session.marks = marks
            session.report = report
            session.save()
            messages.success(request, 'Marks and report added successfully!')
            return redirect('staff_shoptalk_submitted')
        else:
            messages.error(request, 'Please enter marks between 0 and 10')
    
    return render(request, 'staff/shoptalk_mark.html', {'session': session})
