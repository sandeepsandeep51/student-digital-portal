from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/', views.staff_dashboard, name='staff_dashboard'),
    path('profile/', views.staff_profile, name='staff_profile'),
    path('students/', views.staff_students, name='staff_students'),
    path('leave-tracker/', views.staff_leave_tracker, name='staff_leave_tracker'),
    path('weekend-project/', views.staff_weekend_project, name='staff_weekend_project'),
    path('activity-planner/', views.staff_activity_planner, name='staff_activity_planner'),
    path('activity-hours/', views.staff_activity_hours, name='staff_activity_hours'),
    path('latecoming/', views.staff_latecoming, name='staff_latecoming'),  # Add this line
    path('shoptalk/list/', views.staff_shoptalk_list, name='staff_shoptalk_list'),
    path('shoptalk/details/<int:type>/', views.staff_shoptalk_details, name='staff_shoptalk_details'),
    path('shoptalk/modify/', views.modify_shoptalk, name='modify_shoptalk'),
    path('shoptalk/delete/', views.delete_shoptalk, name='delete_shoptalk'),
    path('shoptalk/', views.staff_shoptalk_central, name='staff_shoptalk_central'),
    path('shoptalk/schedule/', views.staff_shoptalk_schedule, name='staff_shoptalk_schedule'),
    path('shoptalk/submitted/', views.staff_shoptalk_submitted, name='staff_shoptalk_submitted'),
    path('shoptalk/pending/', views.staff_shoptalk_pending, name='staff_shoptalk_pending'),
    path('shoptalk/mark/<int:shoptalk_id>/', views.staff_shoptalk_mark, name='staff_shoptalk_mark'),
    path('shoptalk/details/<int:type>/', views.staff_shoptalk_details, name='staff_shoptalk_details'),
]