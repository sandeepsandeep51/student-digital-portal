from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/', views.student_dashboard, name='student_dashboard'),
    path('profile/', views.student_profile, name='student_profile'),
    path('leave/', views.student_leave, name='student_leave'),
    path('shoptalk/', views.student_shoptalk, name='student_shoptalk'),
    path('shoptalk/submit/<int:shoptalk_id>/', views.student_shoptalk_submit, name='student_shoptalk_submit'),
    path('projects/', views.student_projects, name='student_projects'),
    path('latecoming/', views.student_latecoming, name='student_late_coming'),
    path('activity-planner/', views.student_activity_planner, name='student_activity_planner'),
    path('activity-hours/', views.student_activity_hours, name='student_activity_hours'),
    path('feedback/', views.student_feedback, name='student_feedback'),
]