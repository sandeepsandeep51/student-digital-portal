from django.contrib.auth.models import AbstractUser
from django.db import models

class Student(AbstractUser):
    SEMESTER_CHOICES = [
        ('1', '1st Semester'),
        ('2', '2nd Semester'),
        ('3', '3rd Semester'),
        ('4', '4th Semester'),
        ('5', '5th Semester'),
        ('6', '6th Semester'),
    ]
    
    center = models.CharField(max_length=100)
    token_number = models.CharField(max_length=20, unique=True)
    semester = models.CharField(max_length=1, choices=SEMESTER_CHOICES)
    section = models.CharField(max_length=1)
    role = models.CharField(max_length=10, default='student')

    # Add related_name to fix the clash
    groups = models.ManyToManyField(
        'auth.Group',
        related_name='student_user_set',
        blank=True,
        help_text='The groups this user belongs to.',
        verbose_name='groups',
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        related_name='student_user_set',
        blank=True,
        help_text='Specific permissions for this user.',
        verbose_name='user permissions',
    )

    class Meta:
        db_table = 'student'
from django.conf import settings

class ShopTalkSession(models.Model):
    SHOPTALK_TYPES = (
        (1, 'ShopTalk 1'),
        (2, 'ShopTalk 2'),
    )
    
    topic_name = models.CharField(max_length=200)
    scheduled_date = models.DateTimeField()
    deadline = models.DateTimeField()
    status = models.CharField(max_length=20, default='Pending')
    assigned_by = models.ForeignKey(Student, on_delete=models.CASCADE)
    shoptalk_type = models.IntegerField(choices=SHOPTALK_TYPES, default=1)
    
    assigned_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='assigned_sessions')
    status = models.CharField(max_length=20, default='Pending')
    created_at = models.DateTimeField(auto_now_add=True)

class ShopTalkSubmission(models.Model):
    session = models.ForeignKey(ShopTalkSession, on_delete=models.CASCADE)
    student = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    file = models.FileField(upload_to='shoptalk_submissions/')
    submission_date = models.DateTimeField(auto_now_add=True)
    marks = models.IntegerField(null=True, blank=True)
    feedback = models.TextField(null=True, blank=True)
    status = models.CharField(max_length=20, default='Pending')
