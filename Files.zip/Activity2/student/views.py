from django.shortcuts import render, redirect, get_object_or_404  # Add get_object_or_404
from django.contrib.auth.decorators import login_required
from staff.models import ShopTalk
from django.utils import timezone
from django.contrib import messages
from django.urls import reverse
from django.contrib.auth import authenticate, login
from django.shortcuts import render

@login_required
def student_dashboard(request):
    if request.user.role != 'student':
        return redirect('login')
    
    # Get actual ShopTalk sessions count
    shoptalk_count = ShopTalk.objects.filter(status='Pending').count()
    
    context = {
        'pending_leaves': 3,
        'active_projects': 2,
        'shoptalk_sessions': shoptalk_count,  # Using actual count from database
        'activity_hours': 24,
        'shoptalk_url': reverse('student_shoptalk')
    }
    return render(request, 'student/dashboard.html', context)

@login_required
def student_profile(request):
    return render(request, 'student/profile.html')

@login_required
def student_leave(request):
    return render(request, 'student/leave.html')

@login_required
def student_shoptalk(request):
    # Get all ShopTalk sessions
    sessions = ShopTalk.objects.all().order_by('-scheduled_date')
    today = timezone.now().date()
    return render(request, 'student/shoptalk.html', {
        'sessions': sessions,
        'today': today
    })

@login_required
def student_shoptalk_submit(request, shoptalk_id):
    session = get_object_or_404(ShopTalk, id=shoptalk_id)
    
    if request.method == 'POST':
        if 'submission_file' in request.FILES:
            session.submission_file = request.FILES['submission_file']
            session.submission_date = timezone.now()
            session.status = 'Submitted'
            session.save()
            messages.success(request, 'ShopTalk submission uploaded successfully!')
            return redirect('student_shoptalk')
    
    return render(request, 'student/shoptalk_submit.html', {'session': session})

@login_required
def submit_shoptalk(request, session_id):
    if request.method == 'POST':
        session = ShopTalkSession.objects.get(id=session_id)
        file = request.FILES.get('presentation_file')
        
        if not file:
            messages.error(request, 'Please select a file to upload.')
            return redirect('student_shoptalk')
        
        # Validate file type
        allowed_types = ['application/pdf', 'application/vnd.ms-powerpoint', 
                        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                        'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document']
        
        if file.content_type not in allowed_types:
            messages.error(request, 'Invalid file type. Please upload PDF, PPT, or DOCX files only.')
            return redirect('student_shoptalk')
            
        # Create or update submission
        submission, created = ShopTalkSubmission.objects.get_or_create(
            session=session,
            student=request.user,
            defaults={'file': file, 'status': 'Submitted'}
        )
        
        if not created:
            submission.file = file
            submission.status = 'Submitted'
            submission.save()
            
        messages.success(request, 'File uploaded successfully!')
        return redirect('student_shoptalk')
    
    return redirect('student_shoptalk')

@login_required
def student_projects(request):
    return render(request, 'student/projects.html')

@login_required
def student_latecoming(request):
    return render(request, 'student/latecoming.html')

@login_required
def student_activity_planner(request):
    return render(request, 'student/activity_planner.html')

@login_required
def student_activity_hours(request):
    return render(request, 'student/activity_hours.html')

@login_required
def student_feedback(request):
    return render(request, 'student/feedback.html')

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            if user.role == 'student':
                return redirect('student_dashboard')
            elif user.role == 'staff':
                return redirect('staff_dashboard')
        else:
            messages.error(request, 'Invalid username or password')
    
    return render(request, 'login.html')
