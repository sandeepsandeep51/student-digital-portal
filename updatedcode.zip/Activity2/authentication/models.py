from django.contrib.auth.models import AbstractUser
from django.db import models
from django.db.models import Q

class User(AbstractUser):
    ROLE_CHOICES = (
        ('superadmin', 'Super Admin'),
        ('admin', 'Admin'),
        ('staff', 'Staff'),
        ('student', 'Student'),
    )
    
    role = models.CharField(max_length=20, choices=ROLE_CHOICES)
    center = models.ForeignKey('superadmin.Center', on_delete=models.SET_NULL, null=True, blank=True)
    course = models.ForeignKey('superadmin.Course', on_delete=models.SET_NULL, null=True, blank=True)
    phone = models.CharField(max_length=15, blank=True)
    address = models.TextField(blank=True)
    created_by = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='created_users'
    )

    def get_visible_users(self):
        """Return users visible to the current user based on role"""
        if self.role == 'superadmin':
            return User.objects.all()
        elif self.role == 'admin':
            return User.objects.filter(
                Q(created_by=self) |  # Users created by this admin
                Q(pk=self.pk)         # Include self
            )
        return User.objects.none()

    def get_visible_centers(self):
        """Return centers visible to the current user"""
        if self.role == 'superadmin':
            return self.center.__class__.objects.all()
        elif self.role == 'admin':
            return self.center.__class__.objects.filter(
                Q(created_by=self) |
                Q(pk=self.center.pk)
            )
        return self.center.__class__.objects.none()

    def get_visible_courses(self):
        """Return courses visible to the current user"""
        if self.role == 'superadmin':
            return self.course.__class__.objects.all()
        elif self.role == 'admin':
            return self.course.__class__.objects.filter(
                Q(created_by=self) |
                Q(center=self.center)
            )
        return self.course.__class__.objects.none()

class StudentProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='auth_studentprofile')
    student_name = models.CharField(max_length=100)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='auth_created_students')
    course = models.ForeignKey('superadmin.Course', on_delete=models.SET_NULL, null=True)

    def get_visible_profiles(user):
        """Class method to return visible student profiles for a user"""
        if user.role == 'superadmin':
            return StudentProfile.objects.all()
        elif user.role == 'admin':
            return StudentProfile.objects.filter(created_by=user)
        return StudentProfile.objects.none()
