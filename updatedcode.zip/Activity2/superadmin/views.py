from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.http import JsonResponse
from authentication.models import User
from .models import Center, Course
from staff.models import ShopTalkSession
from student.models import LeaveRequest

def is_superadmin(user):
    return user.role == 'superadmin'

def is_admin_or_superadmin(user):
    return user.role in ['admin', 'superadmin']

@login_required
@user_passes_test(is_admin_or_superadmin)
def dashboard(request):
    if request.user.role == 'admin':
        context = {
            'total_centers': Center.objects.filter(id=request.user.center.id).count(),
            'total_courses': Course.objects.filter(center=request.user.center).count(),
            'total_staff': User.objects.filter(role='staff', created_by=request.user).count(),
            'total_students': User.objects.filter(role='student', created_by=request.user).count(),
        }
    else:
        context = {
            'total_centers': Center.objects.count(),
            'total_courses': Course.objects.count(),
            'total_staff': User.objects.filter(role='staff').count(),
            'total_students': User.objects.filter(role='student').count(),
        }
    return render(request, 'superadmin/dashboard.html', context)

@login_required
@user_passes_test(is_admin_or_superadmin)
def admins(request):
    try:
        if request.method == 'POST':
            username = request.POST.get('username')
            email = request.POST.get('email')
            password = request.POST.get('password')
            confirm_password = request.POST.get('confirm_password')
            center_id = request.POST.get('center')
            course_id = request.POST.get('course')
            
            if password != confirm_password:
                messages.error(request, 'Passwords do not match!')
                return redirect('superadmin:admins')
                
            center = Center.objects.get(id=center_id)
            course = Course.objects.get(id=course_id)
            
            admin = User.objects.create_user(
                username=username,
                email=email,
                password=password,
                role='admin',
                center=center,
                created_by=request.user
            )
            admin.course = course
            admin.save()
            
            messages.success(request, 'Administrator created successfully!')
            return redirect('superadmin:admins')
            
        if request.user.role == 'admin':
            admins = User.objects.filter(created_by=request.user).select_related('center', 'course')
            centers = Center.objects.filter(id=request.user.center.id)
            courses = Course.objects.filter(center=request.user.center)
        else:
            admins = User.objects.filter(role='admin').select_related('center', 'course')
            centers = Center.objects.all()
            courses = Course.objects.all()

        return render(request, 'superadmin/admins.html', {
            'admins': admins,
            'centers': centers,
            'courses': courses,
            'is_superadmin': request.user.role == 'superadmin'
        })
        
    except Exception as e:
        messages.error(request, f'Error: {str(e)}')
        return redirect('superadmin:admins')

@login_required
@user_passes_test(is_admin_or_superadmin)
def reports(request):
    if request.user.role == 'admin':
        centers = Center.objects.filter(id=request.user.center.id)
        courses = Course.objects.filter(center=request.user.center)
        users = User.objects.filter(created_by=request.user)
    else:
        centers = Center.objects.all()
        courses = Course.objects.all()
        users = User.objects.all()

    selected_center = request.GET.get('center')
    selected_course = request.GET.get('course')
    
    if selected_center:
        courses = courses.filter(center_id=selected_center)
        users = users.filter(center_id=selected_center)
    
    if selected_course:
        student_profiles = users.filter(
            auth_studentprofile__course_id=selected_course,
            role='student'
        )
        users = users.filter(id__in=student_profiles.values('id'))

    # Calculate statistics for filtered data
    total_students = users.filter(role='student').count()
    total_staff = users.filter(role='staff').count()
    active_courses = courses.count()
    total_centers = centers.count()

    # Course statistics
    course_stats = []
    for course in courses:
        course_stats.append({
            'course_name': course.name,
            'total_students': users.filter(
                auth_studentprofile__course=course,
                role='student'
            ).count(),
            'active_students': users.filter(
                auth_studentprofile__course=course,
                role='student',
                is_active=True
            ).count()
        })

    # Center statistics
    center_stats = []
    centers_to_show = centers
    if selected_center:
        centers_to_show = centers.filter(id=selected_center)
    
    for center in centers_to_show:
        center_stats.append({
            'center_name': center.name,
            'total_staff': users.filter(role='staff', center=center).count(),
            'active_staff': users.filter(role='staff', center=center, is_active=True).count()
        })

    context = {
        'centers': centers,
        'courses': courses,
        'selected_center': int(selected_center) if selected_center else None,
        'selected_course': int(selected_course) if selected_course else None,
        'total_students': total_students,
        'total_staff': total_staff,
        'active_courses': active_courses,
        'total_centers': total_centers,
        'course_stats': course_stats,
        'center_stats': center_stats,
    }
    return render(request, 'superadmin/reports.html', context)

@login_required
@user_passes_test(is_superadmin)
def get_courses_by_center(request, center_id):
    try:
        courses = Course.objects.filter(center_id=center_id).values('id', 'name')
        return JsonResponse({
            'courses': list(courses),
            'status': 'success'
        })
    except Exception as e:
        return JsonResponse({
            'error': str(e),
            'status': 'error'
        }, status=400)

@login_required
@user_passes_test(is_superadmin)
def edit_admin(request, admin_id):
    try:
        admin = get_object_or_404(User, id=admin_id)
        
        if request.method == 'POST':
            # Update basic info
            admin.username = request.POST.get('username')
            admin.email = request.POST.get('email')
            
            # Update center
            center_id = request.POST.get('center')
            center = get_object_or_404(Center, id=center_id)
            admin.center = center
            
            # Update course
            course_id = request.POST.get('course')
            if course_id:
                course = get_object_or_404(Course, id=course_id)
                admin.course = course
            else:
                admin.course = None
            
            # Update active status
            admin.is_active = request.POST.get('is_active') == 'on'
            
            admin.save()
            messages.success(request, 'Administrator updated successfully!')
            return redirect('superadmin:admins')
            
    except Exception as e:
        messages.error(request, f'Error updating administrator: {str(e)}')
    
    return redirect('superadmin:admins')

@login_required
@user_passes_test(is_superadmin)
def delete_admin(request, admin_id):
    admin = get_object_or_404(User, id=admin_id, role='admin')
    
    # Check if user has permission to delete this admin
    if request.user.role != 'superadmin' and request.user.center != admin.center:
        return JsonResponse({'status': 'error', 'message': 'Permission denied'}, status=403)
    
    if request.method == 'POST':
        admin.delete()
        messages.success(request, 'Administrator deleted successfully!')
        return JsonResponse({'status': 'success'})
    return JsonResponse({'status': 'error'}, status=405)


@login_required
@user_passes_test(is_admin_or_superadmin)
def centers(request):
    try:
        if request.method == 'POST':
            name = request.POST.get('name')
            location = request.POST.get('location')
            description = request.POST.get('description')
            
            center = Center.objects.create(
                name=name,
                location=location,
                description=description,
                created_by=request.user
            )
            messages.success(request, 'Center created successfully!')
            return redirect('superadmin:centers')
            
        if request.user.role == 'admin':
            centers = Center.objects.filter(id=request.user.center.id)
        else:
            centers = Center.objects.all()
            
        return render(request, 'superadmin/centers.html', {
            'centers': centers,
            'is_superadmin': request.user.role == 'superadmin'
        })
        
    except Exception as e:
        messages.error(request, f'Error: {str(e)}')
        return redirect('superadmin:centers')

@login_required
@user_passes_test(is_superadmin)
def reports(request):
    centers = Center.objects.all()
    selected_center = request.GET.get('center')
    selected_course = request.GET.get('course')
    
    # Base queryset for courses
    courses = Course.objects.all()
    if selected_center:
        courses = courses.filter(center_id=selected_center)
    
    # Filter statistics based on selection
    users = User.objects.all()
    if selected_center:
        users = users.filter(center_id=selected_center)
    if selected_course:
        # Fix: Filter users through StudentProfile relationship correctly
        student_profiles = User.objects.filter(
            auth_studentprofile__course_id=selected_course,
            role='student'
        )
        users = users.filter(id__in=student_profiles.values('id'))

    # Calculate statistics
    total_students = users.filter(role='student').count()
    total_staff = users.filter(role='staff').count()
    active_courses = courses.count()
    total_centers = Center.objects.count()

    # Course statistics
    course_stats = []
    for course in courses:
        course_stats.append({
            'course_name': course.name,
            'total_students': User.objects.filter(
                auth_studentprofile__course=course,
                role='student'
            ).count(),
            'active_students': User.objects.filter(
                auth_studentprofile__course=course,
                role='student',
                is_active=True
            ).count()
        })

    # Center statistics
    center_stats = []
    centers_to_show = [Center.objects.get(id=selected_center)] if selected_center else Center.objects.all()
    for center in centers_to_show:
        center_stats.append({
            'center_name': center.name,
            'total_staff': User.objects.filter(role='staff', center=center).count(),
            'active_staff': User.objects.filter(role='staff', center=center, is_active=True).count()
        })

    context = {
        'centers': centers,
        'courses': courses,
        'selected_center': int(selected_center) if selected_center else None,
        'selected_course': int(selected_course) if selected_course else None,
        'total_students': total_students,
        'total_staff': total_staff,
        'active_courses': active_courses,
        'total_centers': total_centers,
        'course_stats': course_stats,
        'center_stats': center_stats,
    }
    return render(request, 'superadmin/reports.html', context)

@login_required
@user_passes_test(is_superadmin)
def get_courses_by_center(request, center_id):
    courses = Course.objects.filter(center_id=center_id).values('id', 'name')
    return JsonResponse({'courses': list(courses)})

@login_required
@user_passes_test(is_superadmin)
def activity_logs(request):
    return render(request, 'superadmin/activity_logs.html')

@login_required
@user_passes_test(is_superadmin)
def roles(request):
    roles_data = [
        {
            'id': 1,
            'name': 'Admin',
            'description': 'Center Administrator',
            'permissions': ['Manage Center', 'Manage Courses', 'View Reports']
        },
        {
            'id': 2,
            'name': 'Staff',
            'description': 'Teaching Staff',
            'permissions': ['View Courses', 'Manage Students', 'View Reports']
        },
        {
            'id': 3,
            'name': 'Student',
            'description': 'Student User',
            'permissions': ['View Course Materials', 'Submit Assignments', 'View Grades']
        }
    ]
    return render(request, 'superadmin/roles.html', {'roles': roles_data})

@login_required
@user_passes_test(is_superadmin)
def add_role(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        description = request.POST.get('description')
        permissions = request.POST.getlist('permissions')
        
        # Add role logic here
        messages.success(request, f'Role "{name}" created successfully!')
        return redirect('superadmin:roles')
    return redirect('superadmin:roles')

@login_required
@user_passes_test(is_superadmin)
def edit_role(request, role_id):
    try:
        if request.method == 'POST':
            name = request.POST.get('name')
            description = request.POST.get('description')
            permissions = request.POST.getlist('permissions')

            # Since we're using a static list, we'll update the roles_data list
            roles_data = [
                {
                    'id': 1,
                    'name': 'Admin',
                    'description': 'Center Administrator',
                    'permissions': ['Manage Center', 'Manage Courses', 'View Reports']
                },
                {
                    'id': 2,
                    'name': 'Staff',
                    'description': 'Teaching Staff',
                    'permissions': ['View Courses', 'Manage Students', 'View Reports']
                },
                {
                    'id': 3,
                    'name': 'Student',
                    'description': 'Student User',
                    'permissions': ['View Course Materials', 'Submit Assignments', 'View Grades']
                }
            ]

            # Find and update the role
            for role in roles_data:
                if role['id'] == role_id:
                    role['name'] = name
                    role['description'] = description
                    role['permissions'] = permissions
                    break

            messages.success(request, f'Role "{name}" updated successfully!')
            return redirect('superadmin:roles')

        messages.error(request, 'Invalid request method')
        return redirect('superadmin:roles')

    except Exception as e:
        messages.error(request, f'Error updating role: {str(e)}')
        return redirect('superadmin:roles')

@login_required
@user_passes_test(is_superadmin)
def delete_role(request, role_id):
    if request.method == 'POST':
        # Delete role logic here
        messages.success(request, 'Role deleted successfully!')
        return JsonResponse({'status': 'success'})
    return JsonResponse({'status': 'error'}, status=405)

@login_required
@user_passes_test(is_admin_or_superadmin)
def edit_center(request, center_id):
    try:
        center = get_object_or_404(Center, id=center_id)
        
        # Check if user has permission to edit this center
        if request.user.role == 'admin' and request.user.center.id != center_id:
            messages.error(request, 'You do not have permission to edit this center.')
            return redirect('superadmin:centers')
        
        if request.method == 'POST':
            center.name = request.POST.get('name')
            center.location = request.POST.get('location')
            center.description = request.POST.get('description')
            center.save()
            messages.success(request, 'Center updated successfully!')
            return redirect('superadmin:centers')
            
        return render(request, 'superadmin/edit_center.html', {
            'center': center,
            'is_superadmin': request.user.role == 'superadmin'
        })
        
    except Exception as e:
        messages.error(request, f'Error: {str(e)}')
        return redirect('superadmin:centers')

@login_required
@user_passes_test(is_admin_or_superadmin)
def edit_course(request, course_id):
    try:
        course = get_object_or_404(Course, id=course_id)
        
        # Check if user has permission to edit this course
        if request.user.role == 'admin' and request.user.center != course.center:
            messages.error(request, 'You do not have permission to edit this course.')
            return redirect('superadmin:courses')
        
        if request.method == 'POST':
            course.name = request.POST.get('name')
            course.code = request.POST.get('code')
            course.description = request.POST.get('description')
            center_id = request.POST.get('center')
            
            # Verify center change permission
            new_center = get_object_or_404(Center, id=center_id)
            if request.user.role == 'admin' and request.user.center != new_center:
                messages.error(request, 'You do not have permission to move this course to another center.')
                return redirect('superadmin:courses')
                
            course.center = new_center
            course.save()
            messages.success(request, 'Course updated successfully!')
            return redirect('superadmin:courses')
            
        if request.user.role == 'admin':
            centers = Center.objects.filter(id=request.user.center.id)
        else:
            centers = Center.objects.all()
            
        return render(request, 'superadmin/edit_course.html', {
            'course': course,
            'centers': centers,
            'is_superadmin': request.user.role == 'superadmin'
        })
        
    except Exception as e:
        messages.error(request, f'Error: {str(e)}')
        return redirect('superadmin:courses')

@login_required
@user_passes_test(is_admin_or_superadmin)
def delete_center(request, center_id):
    try:
        center = get_object_or_404(Center, id=center_id)
        
        # Check if user has permission to delete this center
        if request.user.role == 'admin' and request.user.center.id != center_id:
            return JsonResponse({'status': 'error', 'message': 'Permission denied'}, status=403)
        
        if request.method == 'POST':
            center.delete()
            messages.success(request, 'Center deleted successfully!')
            return JsonResponse({'status': 'success'})
            
        return JsonResponse({'status': 'error', 'message': 'Invalid request method'}, status=405)
        
    except Exception as e:
        return JsonResponse({
            'status': 'error',
            'message': str(e)
        }, status=400)

@login_required
@user_passes_test(is_admin_or_superadmin)
def courses(request):
    try:
        if request.method == 'POST':
            name = request.POST.get('name')
            code = request.POST.get('code')
            description = request.POST.get('description')
            center_id = request.POST.get('center')
            
            center = get_object_or_404(Center, id=center_id)
            
            # Check if user has permission to add course to this center
            if request.user.role == 'admin' and request.user.center.id != center.id:
                messages.error(request, 'You do not have permission to add courses to this center.')
                return redirect('superadmin:courses')
            
            course = Course.objects.create(
                name=name,
                code=code,
                description=description,
                center=center,
                created_by=request.user
            )
            messages.success(request, 'Course created successfully!')
            return redirect('superadmin:courses')
            
        if request.user.role == 'admin':
            courses = Course.objects.filter(center=request.user.center)
            centers = Center.objects.filter(id=request.user.center.id)
        else:
            courses = Course.objects.all()
            centers = Center.objects.all()
            
        return render(request, 'superadmin/courses.html', {
            'courses': courses,
            'centers': centers,
            'is_superadmin': request.user.role == 'superadmin'
        })
        
    except Exception as e:
        messages.error(request, f'Error: {str(e)}')
        return redirect('superadmin:courses')

@login_required
@user_passes_test(is_admin_or_superadmin)
def delete_course(request, course_id):
    try:
        course = get_object_or_404(Course, id=course_id)
        
        # Check if user has permission to delete this course
        if request.user.role == 'admin' and request.user.center != course.center:
            return JsonResponse({'status': 'error', 'message': 'Permission denied'}, status=403)
        
        if request.method == 'POST':
            course.delete()
            messages.success(request, 'Course deleted successfully!')
            return JsonResponse({'status': 'success'})
            
        return JsonResponse({'status': 'error', 'message': 'Invalid request method'}, status=405)
        
    except Exception as e:
        return JsonResponse({
            'status': 'error',
            'message': str(e)
        }, status=400)
