from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth import get_user_model
from admin_portal.models import StudentProfile
from staff.models import ShopTalkSession, ShopTalkSubmission
from django.http import JsonResponse

User = get_user_model()

@login_required
def staff_dashboard(request):
    if request.user.role != 'staff':
        return redirect('login')
    context = {
        'total_students': 45,
        'pending_leaves': 7,
        'todays_activities': 3,
        'late_comers': 2
    }
    return render(request, 'staff/dashboard.html', context)

@login_required
def staff_profile(request):
    if request.user.role != 'staff':
        return redirect('login')
    return render(request, 'staff/profile.html')

@login_required
def student_details(request):
    if request.user.role != 'staff':
        return redirect('login')
    
    students = StudentProfile.objects.filter(created_by=request.user)
    return render(request, 'staff/student_details.html', {'students': students})

@login_required
def create_student(request):
    if request.user.role != 'staff':
        return redirect('login')
        
    if request.method == 'POST':
        password = request.POST['password']
        confirm_password = request.POST['confirm_password']
        
        if password != confirm_password:
            messages.error(request, 'Passwords do not match!')
            return redirect('student_details')
            
        try:
            user = User.objects.create_user(
                username=request.POST['username'],
                password=password,
                email=request.POST['email'],
                role='student'  # This will allow student login
            )
            
            student = StudentProfile.objects.create(
                user=user,
                student_name=request.POST['student_name'],
                roll_number=request.POST['roll_number'],
                semester=request.POST['semester'],
                section=request.POST['section'],
                created_by=request.user
            )
            
            messages.success(request, f'Student account created successfully for {student.student_name}')
        except Exception as e:
            messages.error(request, f'Error creating student account: {str(e)}')
            
    return redirect('student_details')

@login_required
def edit_student(request, student_id):
    if request.user.role != 'staff':
        return redirect('login')
        
    student = StudentProfile.objects.get(id=student_id, created_by=request.user)
    
    if request.method == 'POST':
        student.student_name = request.POST['student_name']
        student.roll_number = request.POST['roll_number']
        student.user.email = request.POST['email']
        student.semester = request.POST['semester']
        student.section = request.POST['section']
        
        if request.POST.get('password'):
            student.user.set_password(request.POST['password'])
            
        student.user.save()
        student.save()
        messages.success(request, 'Student details updated successfully')
        return redirect('student_details')
        
    return render(request, 'staff/edit_student.html', {'student': student})

@login_required
def delete_student(request, student_id):
    if request.user.role != 'staff':
        return redirect('login')
        
    try:
        student = StudentProfile.objects.get(id=student_id, created_by=request.user)
        user = student.user
        student.delete()
        user.delete()
        messages.success(request, 'Student deleted successfully')
    except Exception as e:
        messages.error(request, f'Error deleting student: {str(e)}')
        
    return redirect('student_details')

@login_required
def leave_requests(request):
    return render(request, 'staff/leave_requests.html')

@login_required
def staff_shoptalk(request):
    if request.user.role != 'staff':
        return redirect('login')
    
    tab = request.GET.get('tab', 'scheduled')
    
    # Get students created by current staff
    # Update the students query
    students = User.objects.filter(
        role='student',
        studentprofile__created_by=request.user
    ).select_related('studentprofile')
    
    if request.method == 'POST':
        topic = request.POST.get('topic')
        scheduled_date = request.POST.get('scheduled_date')
        description = request.POST.get('description')
        student_id = request.POST.get('selected_students')
        
        session = ShopTalkSession.objects.create(
            staff=request.user,
            topic=topic,
            scheduled_date=scheduled_date,
            description=description
        )
        # Add only the selected student
        session.assigned_students.add(student_id)
        
        messages.success(request, 'Session scheduled successfully!')
        return redirect('staff_shoptalk')
    
    # Get all sessions with their assigned students
    sessions = ShopTalkSession.objects.filter(staff=request.user).order_by('-scheduled_date')
    
    # Get pending submissions
    pending_submissions = ShopTalkSubmission.objects.filter(
        session__staff=request.user,
        status='submitted'
    ).select_related('session', 'student', 'student__studentprofile')
    
    # Get evaluated submissions
    evaluated_submissions = ShopTalkSubmission.objects.filter(
        session__staff=request.user,
        status='evaluated'
    ).select_related('session', 'student', 'student__studentprofile')
    
    # Get not submitted sessions/students
    not_submitted = []
    for session in sessions:
        # Get students who haven't submitted
        not_submitted_students = session.assigned_students.exclude(
            id__in=ShopTalkSubmission.objects.filter(
                session=session
            ).values_list('student_id', flat=True)
        )
        if not_submitted_students.exists():
            not_submitted.append({
                'session': session,
                'students': not_submitted_students
            })
    
    context = {
        'tab': tab,
        'students': students,
        'scheduled_sessions': sessions,
        'pending_submissions': pending_submissions,
        'evaluated_submissions': evaluated_submissions,
        'scheduled_count': sessions.count(),
        'pending_count': pending_submissions.count(),
        'submitted_count': evaluated_submissions.count(),
        'not_submitted': not_submitted,
        'not_submitted_count': len(not_submitted)
    }
    
    return render(request, 'staff/shoptalk.html', context)

@login_required
def assign_marks(request, submission_id):
    if request.method == 'POST':
        submission = ShopTalkSubmission.objects.get(id=submission_id)
        marks = request.POST.get('marks')
        feedback = request.POST.get('feedback')
        
        if 0 <= int(marks) <= 10:
            submission.marks = marks
            submission.feedback = feedback
            submission.status = 'evaluated'
            submission.save()
            messages.success(request, 'Marks assigned successfully!')
        else:
            messages.error(request, 'Marks must be between 0 and 10')
            
    return redirect('staff_shoptalk')

@login_required
def staff_activity_planner(request):
    return render(request, 'staff/activity_planner.html')

@login_required
def staff_activity_hours(request):
    return render(request, 'staff/activity_hours.html')

# Add these new views after the existing staff_shoptalk view

@login_required
def delete_session(request, session_id):
    if request.user.role != 'staff':
        return redirect('login')
        
    try:
        session = ShopTalkSession.objects.get(id=session_id, staff=request.user)
        session.delete()
        messages.success(request, 'Shop Talk session deleted successfully!')
    except ShopTalkSession.DoesNotExist:
        messages.error(request, 'Session not found.')
        
    return redirect('staff_shoptalk')

@login_required
def edit_session(request, session_id):
    if request.user.role != 'staff':
        return redirect('login')
        
    try:
        session = ShopTalkSession.objects.get(id=session_id, staff=request.user)
        
        if request.method == 'POST':
            session.topic = request.POST.get('topic')
            session.scheduled_date = request.POST.get('scheduled_date')
            session.description = request.POST.get('description')
            selected_students = request.POST.getlist('selected_students')
            
            session.save()
            session.assigned_students.set(selected_students)
            
            messages.success(request, 'Shop Talk session updated successfully!')
            return redirect('staff_shoptalk')
            
        # Get students created by this staff through StudentProfile with their names
        student_profiles = StudentProfile.objects.filter(created_by=request.user)
        students = User.objects.filter(studentprofile__in=student_profiles).values('id', 'studentprofile__student_name')
        
        return render(request, 'staff/edit_session.html', {
            'session': session,
            'students': students
        })
        
    except ShopTalkSession.DoesNotExist:
        messages.error(request, 'Session not found.')
        return redirect('staff_shoptalk')
